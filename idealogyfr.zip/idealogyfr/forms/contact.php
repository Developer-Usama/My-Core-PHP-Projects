<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$receiving_email_address = 'your-email';

if (file_exists($php_email_form = '../assets/vendor/php-email-form/php-email-form.php')) {
    include($php_email_form);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Unable to load the "PHP Email Form" Library!']);
    exit;
}

$contact = new PHP_Email_Form;
$contact->ajax = true;
$contact->to = $receiving_email_address;
$contact->from_name = $_POST['name'];
$contact->from_email = $_POST['email'];
$contact->subject = $_POST['subject']; // Updated to fetch the subject from form data

$contact->smtp = array(
    'host' => 'smtp.gmail.com',
    'username' => 'your-email',
    'password' => 'psd',
    'port' => 'port_num'
);

// Add messages for each form field
$contact->add_message($_POST['name'], 'Name');
$contact->add_message($_POST['email'], 'Email');
$contact->add_message($_POST['subject'], 'Subject'); // New line for Subject
$contact->add_message($_POST['contactMethod'], 'Contact Method');
$contact->add_message($_POST['contactNumber'], 'Contact Number');
$contact->add_message($_POST['budget'], 'Budget');
$contact->add_message($_POST['message'], 'Message');

// Try sending and return success or failure response
if ($contact->send()) {
    echo json_encode(['status' => 'success', 'message' => 'Your message has been sent successfully!']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'There was an error sending your message. Please try again later.']);
}
?>
