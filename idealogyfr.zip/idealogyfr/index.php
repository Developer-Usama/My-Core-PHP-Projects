<?php
session_start();

// Check if `lang` parameter is in the URL (from .htaccess rewrite)
$urlLang = isset($_GET['lang']) ? $_GET['lang'] : null;

if ($urlLang && in_array($urlLang, ['fr', 'en'])) {
    // Set language from URL if it's either 'fr' or 'en'
    $_SESSION['lang'] = $urlLang;
} elseif (!isset($_SESSION['lang'])) {
    // Fallback to browser-based language detection only if no session language is set
    $browserLanguages = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    $languages = explode(',', $browserLanguages);
    $preferredLanguage = substr($languages[0], 0, 2); // Get the first language code

    // Define supported languages, with a default if the preferred is unsupported
    $supportedLanguages = ['en', 'fr'];
    $_SESSION['lang'] = in_array($preferredLanguage, $supportedLanguages) ? $preferredLanguage : 'en';

    // Optional: Display the browser's preferred language for testing
    // echo "Your browser's preferred language is: " . htmlspecialchars($preferredLanguage);
}

// Set language to be used on the page
$defaultLang = $_SESSION['lang'] ?? 'en'; // Default to 'en' if session is unset
// Include the header file after defining $defaultLang
include 'includes/header.php';
?>


<body>
    <!-- Loader Spinner -->
    <div id="loader" class="loader">
        <div class="spinner"></div>
    </div>

    <?php
    // Load JSON data
    $headerData = json_decode(file_get_contents('data/fr/header-menu.json'), true);
    $slidesData = json_decode(file_get_contents('data/fr/slider-data.json'), true);
    $whyUsData = json_decode(file_get_contents('data/fr/why-us.json'), true);

    $techData = json_decode(file_get_contents('data/fr/technologies.json'), true); // Load technologies data
    $portfolioData  = json_decode(file_get_contents('data/fr/services.json'), true); // Load technologies data
    $aboutContent  = json_decode(file_get_contents('data/fr/about-us.json'), true); // Load technologies data
    $careersContent  = json_decode(file_get_contents('data/fr/careers.json'), true); // Load technologies data
    $offersData = json_decode(file_get_contents("data/fr/our-offers.json"), true); // Load offers data



    $contactData   = json_decode(file_get_contents('data/fr/contact.json'), true); // Load technologies data

    $footerContentData = json_decode(file_get_contents('data/fr/footer.json'), true); // Load technologies data

    $slides = $slidesData['slides'];

    // Access main text and technologies
    $mainText = $techData['mainText'];
    $technologies = $techData['technologies'];

    // Step 1: Load the JSON file and decode it into a PHP array
    $jsonData = file_get_contents('data/fr/slider-data.json'); // Adjust the path to your JSON file
    $slides = json_decode($jsonData, true)['slides']; // Assuming your JSON structure has "slides" as the main key

    // Assuming the first slide is always the one you want to customize
    $firstSlide = $slidesData['slides'][0];
    $secondSlide = $slidesData['slides'][1];
    $thirdSlide = $slidesData['slides'][2];
    $fourthSlide = $slidesData['slides'][3];
    $fifthSlide = $slidesData['slides'][4];
    $sixthSlide = $slidesData['slides'][5];
    $seventhSlide = $slidesData['slides'][6];
    $eighthSlide = $slidesData['slides'][7];
    $ninthSlide = $slidesData['slides'][8];
    $tenthSlide = $slidesData['slides'][9];
    ?>

    <!-- header section -->
    <header>
        <div class="logo">
            <a href="#home">
                <!-- Add the URL where you want the logo to redirect -->
                <img id="logoImage" src="<?php echo $headerData['logo'] ?? 'default-logo.png'; ?>" alt="Logo" />
            </a>
        </div>

        <ul class="navlist" id="navLinks">
            <?php if (isset($headerData['navLinks']) && is_array($headerData['navLinks']) && count($headerData['navLinks']) > 0): ?>
                <?php foreach ($headerData['navLinks'] as $index => $link): ?>
                    <li>
                        <a href="<?php echo $link['href']; ?>" class="<?php echo isset($link['active']) ? 'active' : ''; ?>" style="--i:<?php echo $index + 1; ?>;">
                            <?php echo $link['name']; ?>
                        </a>

                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li><a href="#">No menu items available</a></li>
            <?php endif; ?>
        </ul>

        <!-- Language switcher -->
        <div class="language-switcher">
            <button id="langButton" class="lang-btn" data-lang="fr">
                <img src="assets/images/fr.png" alt="Français" />
            </button>
        </div>

        <div id="menu-icon" class="bx bx-menu"></div>

        <!-- for scrolltop bar line -->
        <div class="header-bar">
            <div class="progress-container">
                <div class="progress-bar" id="myBar"></div>
            </div>
        </div>
    </header>


    <!-- script for progress bar -->
    <script>
        // When the user scrolls the page, execute myFunction 
        window.onscroll = function() {
            myFunction()
        };

        function myFunction() {
            var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            var scrolled = (winScroll / height) * 100;
            document.getElementById("myBar").style.width = scrolled + "%";
        }
    </script>


    <!-- main slider section -->
    <div id="home" class="demo-cont">
        <!-- slider start -->
        <div class="fnc-slider example-slider">
            <div class="fnc-slider__slides">


                <!-- slide start -->
                <div class="fnc-slide m--active-slide m--fade-in">
                    <div class="fnc-slide__inner">
                        <img src="<?php echo $firstSlide['image']; ?>" alt="Logo" id="welcome-image" class="fnc-slide__log">
                        <div class="fnc-slide__content" id="welcome-title">
                            <h2 class="fnc-slide__heading heading-animate">
                                <div class="fnc-slide__heading-line">
                                    <span><?php echo $firstSlide['title']; ?></span>
                                </div>
                            </h2>
                            <h3 class="fnc-slide__subheading animated-text" data-text="Slide 0" id="welcome-subtitle">
                                <span data-text="Credits"><?php echo $firstSlide['subtitle']; ?></span>
                            </h3>
                        </div>
                        <!-- New Section for Image Boxes -->
                        <div class="fnc-slide__image-boxes ">

                            <?php
                            // Loop through the image boxes for the first slide from the json file slider-data.json
                            foreach ($firstSlide['imageBoxes'] as $box) {
                                echo '<a href="' . $box['url'] . '" target="_blank" class="fnc-slide__image-box">';
                                echo '<img src="' . $box['boxImage'] . '" alt="'  . '" />';
                                echo '<span>' . $box['boxText'] . '</span>'; // Optional text under the image
                                echo '</a>';
                            }
                            ?>

                        </div>
                    </div>
                </div>
                <!-- slide end -->
                <!-- Loop for Other Slides -->
                <?php
                $slides = [$secondSlide, $thirdSlide, $fourthSlide, $fifthSlide, $sixthSlide, $seventhSlide, $eighthSlide, $ninthSlide, $tenthSlide];
                $slideClasses = [
                    'm--blend m--scale-up',
                    'm--blend m--slide-right-to-left',
                    'm--blend m--slide-up',
                    'm--blend m--slide-down',
                    'm--blend m--slide-right-to-left',
                    'm--blend m--slide-left-to-right',
                    'm--blend m--fade-in',
                    'm--blend m--slide-down',
                    'm--blend m--fade-in'
                ];

                foreach ($slides as $index => $slide):
                ?>
                    <div class="fnc-slide <?php echo $slideClasses[$index]; ?>">
                        <div class="fnc-slide__inner">
                            <img src="<?php echo $slide['image']; ?>" alt="Logo" class="fnc-slide__logo">
                            <div class="fnc-slide__content">
                                <h2 class="fnc-slide__heading heading-animate">
                                    <div class="fnc-slide__heading-line">
                                        <span><?php echo $slide['title']; ?></span>
                                    </div>
                                </h2>
                                <h3 class="fnc-slide__subheading animated-text" data-text="Slide <?php echo $index + 1; ?>">
                                    <span data-text="Credits"><?php echo $slide['subtitle']; ?></span>
                                </h3>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <!-- End of Slide Loop -->

            </div>
            <!-- Slider End -->

            <!-- Slider Navigation -->
            <nav class="fnc-nav">
                <div class="fnc-nav__bgs">
                    <div class="fnc-nav__bg m--navbg-gradient-1 m--active-nav-bg"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-2"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-3"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-4"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-5"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-6"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-7"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-8"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-9"></div>
                    <div class="fnc-nav__bg m--navbg-gradient-10"></div>
                </div>

                <div class="fnc-nav__controls">
                    <!-- Button for the First Slide -->
                    <button class="fnc-nav__control m--active-control" data-index="0">
                        <?php echo $firstSlide['navButtonText']; ?>
                        <span class="fnc-nav__control-progress"></span>
                    </button>

                    <!-- Loop for the Other Slides -->
                    <?php foreach ($slides as $index => $slide): ?>
                        <button class="fnc-nav__control" data-index="<?php echo $index + 1; ?>">
                            <?php echo $slide['navButtonText']; ?>
                            <span class="fnc-nav__control-progress"></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </nav>

        </div>
        <!-- slider end -->
    </div>

    <!-- Why-us section -->
    <section id="why-us" class="why-us">
        <div class="main-text scroll-scale">
            <h2><?php echo $whyUsData['whyUs']['mainText']['heading']; ?></h2>
        </div>

        <div class="why-us-content scroll-scale">
            <?php foreach ($whyUsData['whyUs']['content']['sections'] as $section) { ?>
                <h2><?php echo $section['title']; ?></h2>
                <p><?php echo $section['paragraph']; ?></p>
            <?php } ?>


        </div>
        <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>
    </section>


    <!-- technologies section  ------------------------------------------------->
    <section id="technologies" class="technologies">
        <div class="main-text-black scroll-scale">
            <h2><?php echo $mainText['title']; ?></h2>
            <span><?php echo $mainText['subtitle']; ?></span>
        </div>

        <div class="section-technologies scroll-bottom">
            <?php foreach ($technologies as $tech): ?>
                <div class="technology-box">
                    <img src="<?php echo $tech['image']; ?>" alt="<?php echo $tech['alt']; ?>" class="technology-image">
                    <div class="content"> <!-- This is the content class -->
                        <h3 class="technology-heading"><?php echo $tech['heading']; ?></h3> <!-- Always visible -->
                        <p><?php echo $tech['description']; ?></p>
                    </div>
                    <!-- Removed the overlay div -->
                </div>
            <?php endforeach; ?>
        </div>
        <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>
    </section>


    <!-- Services section -->
    <section id="services" class="portfolio">
        <div class="main-text scroll-scale">
            <h2><?php echo $portfolioData['portfolio']['mainText']['heading']; ?></h2>
            <span><?php echo $portfolioData['portfolio']['mainText']['span']; ?></span>
        </div>

        <!-- Flexbox container for the left (paragraphs) and right (gallery) sides -->
        <div class="services-content">
            <!-- Left side: Paragraphs -->
            <div class="services-paragraphs">
                <?php foreach ($portfolioData['portfolio']['introduction'] as $paragraph) { ?>
                    <p><?php echo $paragraph; ?></p>
                <?php } ?>
            </div>

            <!-- Right side: Image gallery -->
            <div class="services-gallery">
                <div class="portfolio-gallery scroll-scale">
                    <?php foreach ($portfolioData['portfolio']['portfolioItems'] as $item) { ?>
                        <div class="port-box">
                            <div class="port-image">
                                <img src="<?php echo $item['image']; ?>" alt="Error to load the Pic">
                            </div>
                            <div class="port-content">
                                <h3 class="services-heading"><?php echo $item['title']; ?></h3>
                                <p><?php echo $item['description']; ?></p>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>

        <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>
    </section>

    <!-- Offers Section -->
    <section id="offers" class="offers-section">
        <div class="main-text-black scroll-scale">
            <h2 id="offersTitle"><?php echo $offersData['offers']['title']; ?></h2>
            <span id="offersDescription"><?php echo $offersData['offers']['description']; ?></span>
        </div>

        <div class="main1">
            <div class="half-section first-li">
                <ul class="first-ul-li" id="firstHalfOffers">
                    <?php foreach ($offersData['offers']['items'] as $index => $offer): ?>
                        <?php if ($index < 4): ?>
                            <li class="first-ul-li">
                                <div class="slidetitle">
                                    <span><?php echo $offer['title']; ?></span>
                                </div>
                                <p class="description"><?php echo $offer['description']; ?></p>
                                <a href="<?php echo $offer['link']; ?>">
                                    <img src="<?php echo $offer['image']; ?>" alt="<?php echo $offer['title']; ?>" />
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="half-section second-li">
                <ul id="secondHalfOffers">
                    <?php foreach ($offersData['offers']['items'] as $index => $offer): ?>
                        <?php if ($index >= 4): ?>
                            <li>
                                <div class="slidetitle">
                                    <span><?php echo $offer['title']; ?></span>
                                </div>
                                <p class="description"><?php echo $offer['description']; ?></p>
                                <a href="<?php echo $offer['link']; ?>">
                                    <img src="<?php echo $offer['image']; ?>" alt="<?php echo $offer['title']; ?>" />
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <a href="#home" class="arrow"><i class="bx bx-up-arrow-alt"></i></a>
    </section>


    <!-- About Us Section -->
    <section id="about-us" class="about-us">
        <div class="main-text scroll-scale">
            <h2 id="aboutTitle"><?php echo $aboutContent['mainText']['title']; ?></h2>
            <span id="aboutSubtitle"><?php echo $aboutContent['mainText']['subtitle']; ?></span>
        </div>

        <div class="about-content scroll-scale">
            <div class="left-column">
                <h2 class="big-heading" id="aboutBigHeading"><?php echo $aboutContent['aboutContent']['bigHeading']; ?></h2>

                <?php foreach ($aboutContent['aboutContent']['description'] as $para): ?>
                    <p><?php echo $para; ?></p>
                <?php endforeach; ?>
            </div>

            <div class="right-column">
                <div class="row">
                    <div class="column">
                        <div class="icon">
                            <i class="bx bx-history"></i>
                        </div>
                        <h3 id="aboutHistoryTitle"><?php echo $aboutContent['aboutContent']['history']['title']; ?></h3>
                        <p id="aboutHistoryText"><?php echo $aboutContent['aboutContent']['history']['text']; ?></p>
                    </div>
                    <div class="column">
                        <div class="icon">
                            <i class="bx bx-briefcase"></i>
                        </div>
                        <h3 id="aboutWorkTitle"><?php echo $aboutContent['aboutContent']['work']['title']; ?></h3>
                        <p id="aboutWorkText"><?php echo $aboutContent['aboutContent']['work']['text']; ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="column">
                        <div class="icon">
                            <i class="bx bx-code-alt"></i>
                        </div>
                        <h3 id="aboutDevelopmentTitle"><?php echo $aboutContent['aboutContent']['development']['title']; ?></h3>
                        <p id="aboutDevelopmentText"><?php echo $aboutContent['aboutContent']['development']['text']; ?></p>
                    </div>
                    <div class="column">
                        <div class="icon">
                            <i class="bx bx-map-pin"></i>
                        </div>
                        <h3 id="aboutIdealogyFranceTitle"><?php echo $aboutContent['aboutContent']['idealogyFrance']['title']; ?></h3>
                        <p id="aboutIdealogyFranceText"><?php echo $aboutContent['aboutContent']['idealogyFrance']['text']; ?></p>
                    </div>
                </div>
            </div>
        </div>


        <!-- Careers Section -->
        <div id="careers-section" class="careers-section scroll-bottom">
            <div class="careers-image">
                <img src="<?php echo $careersContent['careersContent']['image']; ?>" alt="Careers" />
            </div>

            <div class="careers-content">
                <h3 id="careersHeading"><?php echo $careersContent['careersContent']['heading']; ?></h3>
                <p class="light-text"><?php echo $careersContent['careersContent']['intro']['lightText']; ?></p>
                <p class="normal-text"><?php echo $careersContent['careersContent']['intro']['normalText']; ?></p>
                <ul>
                    <?php foreach ($careersContent['careersContent']['positions'] as $position): ?>
                        <li><?php echo $position; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>

    </section>


    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="main-text-black scroll-scale">
            <h2><?php echo $contactData['contact']['mainText']['heading']; ?></h2>
            <span><?php echo $contactData['contact']['mainText']['span']; ?></span>
        </div>

        <form action="forms/contact.php" method="POST" role="form" class="scroll-bottom php-email-form">
           
                <input type="text" name="name" placeholder="<?php echo $contactData['contact']['form']['name']; ?>" required>
                <input type="email" name="email" placeholder="<?php echo $contactData['contact']['form']['email']; ?>" required>
         

            <!-- Radio buttons for selecting telephone or WhatsApp -->
            <div class="select-number-type">
                <?php foreach ($contactData['contact']['form']['contactMethod']['options'] as $option): ?>
                    <input type="radio" id="<?php echo $option['value']; ?>" name="contactMethod" value="<?php echo $option['value']; ?>" required>
                    <label for="<?php echo $option['value']; ?>"><?php echo $option['label']; ?></label>
                <?php endforeach; ?>
            </div>

            <!-- Input for contact number -->
            <input type="tel" name="contactNumber" placeholder="<?php echo $contactData['contact']['form']['contactNumber']; ?>" required>

            <!-- Dropdown for budget selection -->
            <div class="select-container">
                <select name="budget" required class="custom-select">
                    <option value="" disabled selected><?php echo $contactData['contact']['form']['budget']['placeholder']; ?></option>
                    <?php foreach ($contactData['contact']['form']['budget']['options'] as $option): ?>
                        <option value="<?php echo $option; ?>"><?php echo $option; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            
            <!-- New input for Subject -->
            <input type="text" name="subject" placeholder="<?php echo $contactData['contact']['form']['subject']; ?>" required>

            <!-- Textarea for message -->
            <textarea name="message" cols="30" rows="10" placeholder="<?php echo $contactData['contact']['form']['message']; ?>" required></textarea>

            <!-- Loading Spinner -->
            <div id="formLoadingSpinner" class="form-loader" style="display: none;"></div>

            <!-- Submit button -->
            <div class="btn-box formBtn">
                <button type="submit" class="btn"><?php echo $contactData['contact']['form']['submitButton']; ?></button>
            </div>
        </form>


        <!-- Modal for submission messages -->
        <div class="modal" id="messageModal" style="display: none;">
            <div class="modal-content">
                <span class="close-button"></span>
                <div class="modal-message"></div>
                <button id="okButton" class="btn"><?php echo $contactData['contact']['modalMessages']['okButton']; ?></button>
            </div>
        </div>

        <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>


    </section>


    <!-- Footer Section -->
    <footer class="footer">
        <p class="scroll-scale" id="footerContent">
            <?php echo $footerContentData['copyright']; ?>
            <br style="text-align: center;">
            <?php echo $footerContentData['poweredBy']; ?>
            <span><?php echo $footerContentData['span']; ?></span>
        </p>

        <!-- Logo Container -->
        <div class="footer-logos" id="footerLogos">
            <?php if (isset($footerContentData['logoLinks']) && is_array($footerContentData['logoLinks'])): ?>
                <?php foreach ($footerContentData['logoLinks'] as $logo): ?>
                    <a href="<?php echo $logo['url']; ?>" target="_blank">
                        <img src="<?php echo $logo['image']; ?>" alt="<?php echo $logo['alt']; ?>">
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No logos available</p>
            <?php endif; ?>
        </div>
    </footer>


    <!-- JavaScript for form submission and modal display -->
    <script src="assets/js/jquery-3.6.0.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const form = document.querySelector(".php-email-form");
            const modal = document.getElementById("messageModal");
            const modalMessage = modal.querySelector(".modal-message");
            const closeButton = modal.querySelector(".close-button");
            const okButton = document.getElementById("okButton");

            let contactData = {};

            const langButton = document.getElementById('langButton');
            let currentLang = '<?php echo $defaultLang; ?>'; // Load default language from PHP session
            const flagImage = langButton.querySelector('img'); // Get the img element

            // Load content based on selected language
            function loadContent(lang) {
                fetch(`data/${lang}/contact.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        contactData = data.contact;
                        // Update form fields
                        document.querySelector('.contact h2').textContent = contactData.mainText.heading;
                        document.querySelector('.contact span').textContent = contactData.mainText.span;
                        document.querySelector('input[name="name"]').placeholder = contactData.form.name;
                        document.querySelector('input[name="email"]').placeholder = contactData.form.email;
                        document.querySelector('input[name="subject"]').placeholder = contactData.form.subject; // New line for Subject
                        document.querySelector('input[name="contactNumber"]').placeholder = contactData.form.contactNumber;
                        document.querySelector('textarea[name="message"]').placeholder = contactData.form.message;

                        const radioContainer = document.querySelector('.select-number-type');
                        radioContainer.innerHTML = '';
                        contactData.form.contactMethod.options.forEach(option => {
                            radioContainer.innerHTML += `
                            <input type="radio" id="${option.value}" name="contactMethod" value="${option.value}" required>
                            <label for="${option.value}">${option.label}</label>
                        `;
                        });

                        const budgetSelect = document.querySelector('select[name="budget"]');
                        budgetSelect.innerHTML = `<option value="" disabled selected>${contactData.form.budget.placeholder}</option>`;
                        contactData.form.budget.options.forEach(option => {
                            budgetSelect.innerHTML += `<option value="${option}">${option}</option>`;
                        });

                        document.querySelector('.btn-box .btn').textContent = contactData.form.submitButton;
                        okButton.textContent = contactData.modalMessages.okButton;

                        console.log('Content updated for language:', lang);
                    })
                    .catch(error => console.error('Error loading contact data:', error));
            }

            // Load initial content based on detected language
            loadContent(currentLang);

            // Language switcher button click event
            langButton.addEventListener('click', function() {
                currentLang = langButton.getAttribute('data-lang'); // Get the next language to switch to
                loadContent(currentLang); // Load content for the new language
            });

            // Form submission event
            form.addEventListener("submit", function(event) {
                event.preventDefault();
                // Clear previous error styles
                const inputs = form.querySelectorAll('input, select, textarea');
                inputs.forEach(input => {
                    input.classList.remove('error');
                });

                let isValid = true;

                // Validate each input field
                const name = form.querySelector('input[name="name"]');
                if (!name.value) {
                    name.classList.add('error');
                    modalMessage.textContent = contactData.form.errors.name; // Error from JSON
                    isValid = false;
                }

                const email = form.querySelector('input[name="email"]');
                if (!email.value || !validateEmail(email.value)) {
                    email.classList.add('error');
                    modalMessage.textContent = !email.value ? contactData.form.errors.email : contactData.modalMessages.invalidEmail;
                    isValid = false;
                }

                const subject = form.querySelector('input[name="subject"]');
                if (!subject.value) {
                    subject.classList.add('error');
                    modalMessage.textContent = contactData.form.errors.subject; // Error from JSON
                    isValid = false;
                }

                const contactMethod = form.querySelector('input[name="contactMethod"]:checked');
                if (!contactMethod) {
                    modalMessage.textContent = contactData.form.errors.contactMethod; // Error from JSON
                    isValid = false;
                }

                const contactNumber = form.querySelector('input[name="contactNumber"]');
                if (!contactNumber.value) {
                    contactNumber.classList.add('error');
                    modalMessage.textContent = contactData.form.errors.contactNumber; // Error from JSON
                    isValid = false;
                }

                const budget = form.querySelector('select[name="budget"]');
                if (!budget.value) {
                    budget.classList.add('error');
                    modalMessage.textContent = contactData.form.errors.budget; // Error from JSON
                    isValid = false;
                }

                const message = form.querySelector('textarea[name="message"]');
                if (!message.value) {
                    message.classList.add('error');
                    modalMessage.textContent = contactData.form.errors.message; // Error from JSON
                    isValid = false;
                }

                // If not valid, show modal and exit
                if (!isValid) {
                    modal.style.display = "flex";
                    return; // Exit the function to prevent form submission
                }

                // Show loading spinner and disable body
                document.getElementById("formLoadingSpinner").style.display = "flex"; // Show spinner
                document.body.classList.add("loading"); // Add loading class

                const formData = $(this).serialize();
                $.ajax({
                    type: 'POST',
                    url: form.action,
                    data: formData,
                    success: function(response) {
                        let jsonResponse;
                        try {
                            jsonResponse = JSON.parse(response);
                        } catch (e) {
                            console.error("Failed to parse JSON response:", e);
                            jsonResponse = {
                                status: "error"
                            };
                        }

                        // Use contactData to display messages dynamically
                        if (jsonResponse.status === "success") {
                            modalMessage.classList.remove("error");
                            modalMessage.classList.add("success");
                            modalMessage.textContent = contactData.modalMessages.success; // Success message
                            form.reset(); // Clear the form
                        } else {
                            modalMessage.classList.remove("success");
                            modalMessage.classList.add("error");
                            modalMessage.textContent = contactData.modalMessages.error; // Error message
                        }
                        modal.style.display = "flex";
                    },
                    error: function() {
                        modalMessage.classList.remove("success");
                        modalMessage.classList.add("error");
                        modalMessage.textContent = contactData.modalMessages.error; // Error message
                        modal.style.display = "flex";
                    },
                    complete: function() {
                        // Hide loading spinner and enable body
                        document.getElementById("formLoadingSpinner").style.display = "none"; // Hide spinner
                        document.body.classList.remove("loading"); // Remove loading class
                    }
                });
            });

            // Helper function to validate email format
            function validateEmail(email) {
                const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return regex.test(email);
            }

            // Close modal functionality
            closeButton.addEventListener("click", () => modal.style.display = "none");
            okButton.addEventListener("click", () => modal.style.display = "none");

            // Close modal when clicking outside
            window.addEventListener("click", function(event) {
                if (event.target === modal) modal.style.display = "none";
            });
        });
    </script>


    <!-- script for form select value for budget -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const selectElement = document.querySelector("select[name='budget']");

            selectElement.addEventListener("change", function() {
                // Check if a value has been selected
                if (this.value) {
                    this.style.color = "#292e33"; // Change the text color to red
                } else {
                    this.style.color = ""; // Reset to the default color if no selection
                }
            });
        });
    </script>


    <!-- for flags/lang selection from headder -->
    <script>
        // <!-- loader spinner -->
        window.addEventListener("load", function() {
            // Hide loader after page load
            setTimeout(function() {
                document.getElementById("loader").style.display = "none";

                // Start slider animation after loader disappears
                const slider = document.querySelector('.fnc-slider');
                slider.classList.add('start-slider'); // Custom class to trigger slider

            }, 1000); // Loader visible for 1 second after page load
        });

        document.addEventListener('DOMContentLoaded', function() {
            const langButton = document.getElementById('langButton');
            let currentLang = '<?php echo $defaultLang; ?>'; // Load default language from PHP session
            const flagImage = langButton.querySelector('img'); // Get the img element

            // Function to load the JSON content based on selected language
            function loadContent(lang) {

                // // for to send the selected lang to head file for meta tags loading accordn to lang
                // // Send AJAX request to store the selected language in the session
                // fetch('includes/header.php', {
                //     method: 'POST',
                //     headers: {
                //       'Content-Type': 'application/x-www-form-urlencoded',
                //     },
                //     body: `lang=${lang}`
                //   })
                //   .then(response => response.text())
                //   .then(data => {

                //   })
                //   .catch(error => console.error('Error storing language in session:', error));

                // Fetch the header and menu data
                fetch(`data/${lang}/header-menu.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        // Update the logo
                        document.getElementById('logoImage').src = data.logo;

                        // Update the navigation links
                        const navLinks = document.getElementById('navLinks');
                        navLinks.innerHTML = ''; // Clear the current links
                        data.navLinks.forEach(link => {
                            const li = document.createElement('li');
                            li.innerHTML = `<a href="${link.href}" class="${link.active ? 'active' : ''}">${link.name}</a>`;
                            navLinks.appendChild(li);
                        });

                        console.log('Header content updated for language:', lang);

                        // Update the button to show the corresponding flag image and toggle the language
                        if (lang === 'fr') {
                            flagImage.src = 'assets/images/lang/uk-round-md.png'; // Change to English flag
                            langButton.setAttribute('data-lang', 'en'); // Next language to switch to
                        } else {
                            flagImage.src = 'assets/images/lang/fr-round-md.png'; // Change to French flag
                            langButton.setAttribute('data-lang', 'fr'); // Next language to switch to
                        }
                    })
                    .catch(error => console.error('Error loading header data:', error));

                // Fetch the slider content
                fetch(`data/${lang}/slider-data.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(sliderData => {
                        const slides = document.querySelectorAll('.fnc-slide'); // Get all slides
                        const buttons = document.querySelectorAll('.fnc-nav__control'); // Get all buttons

                        // Ensure that the number of slides in the JSON matches the number of HTML slides
                        if (sliderData.slides.length >= slides.length) {
                            // Loop through each slide and update its content
                            sliderData.slides.forEach((slideData, index) => {
                                const slide = slides[index];

                                // Update image
                                const slideImage = slide.querySelector('img');
                                slideImage.src = slideData.image;

                                // Update title
                                const slideTitle = slide.querySelector('.fnc-slide__heading span');
                                slideTitle.textContent = slideData.title;

                                // Update subtitle
                                const slideSubtitle = slide.querySelector('.fnc-slide__subheading span');
                                slideSubtitle.textContent = slideData.subtitle;

                                // Update image boxes (if present)
                                const imageBoxesContainer = slide.querySelector('.fnc-slide__image-boxes');
                                if (imageBoxesContainer) {
                                    imageBoxesContainer.innerHTML = ''; // Clear existing boxes
                                    slideData.imageBoxes.forEach(box => {
                                        const aTag = document.createElement('a');
                                        aTag.href = box.url;
                                        aTag.target = '_blank';
                                        aTag.className = 'fnc-slide__image-box';
                                        aTag.innerHTML = `<img src="${box.boxImage}" alt="${box.boxText}"><span>${box.boxText}</span>`;
                                        imageBoxesContainer.appendChild(aTag);
                                    });
                                }
                            });

                            // Update button texts while preserving the progress bars
                            buttons.forEach((button, index) => {
                                const progressBar = button.querySelector('.fnc-nav__control-progress'); // Get the progress bar
                                button.innerHTML = sliderData.slides[index].navButtonText; // Update button text
                                button.appendChild(progressBar); // Re-attach the progress bar
                            });
                        }
                    })
                    .catch(error => console.error('Error loading slider data:', error));

                // Update "Why Us" Section
                fetch(`data/${lang}/why-us.json?${new Date().getTime()}`)

                    .then(response => response.json())
                    .then(data => {
                        const whyUsSection = document.getElementById('why-us');
                        whyUsSection.querySelector('.main-text h2').textContent = data.whyUs.mainText.heading;

                        // Update the content sections dynamically
                        const content = whyUsSection.querySelector('.why-us-content');
                        content.innerHTML = ''; // Clear existing content

                        // Create new content sections
                        data.whyUs.content.sections.forEach(section => {
                            const h2 = document.createElement('h2');
                            h2.textContent = section.title;
                            const p = document.createElement('p');
                            p.textContent = section.paragraph;
                            content.appendChild(h2);
                            content.appendChild(p);
                        });


                    })
                    .catch(error => console.error('Error loading Why Us data:', error));


                // Fetch the content data (both main text and technologies)
                fetch(`data/${lang}/technologies.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        const techSection = document.getElementById('technologies'); // Target the technologies section

                        // Update main text (title and subtitle)
                        const mainText = techSection.querySelector('.main-text-black');
                        mainText.querySelector('span').textContent = data.mainText.subtitle; // Update subtitle
                        mainText.querySelector('h2').textContent = data.mainText.title; // Update title

                        const techItemsContainer = techSection.querySelector('.section-technologies'); // Get the container for technology items

                        // Clear the current technology items
                        techItemsContainer.innerHTML = '';

                        // Loop through technologies and create new elements
                        data.technologies.forEach(tech => {
                            const techDiv = document.createElement('div');
                            techDiv.className = 'technology-box'; // Keep the existing class
                            techDiv.innerHTML = `
            <img src="${tech.image}" alt="${tech.alt}" class="technology-image" />
            <div class="overlay">
              <h3>${tech.heading}</h3>
              <p>${tech.description}</p>
            </div>
            <div class="btn-box technology-btn"></div>
          `;
                            techItemsContainer.appendChild(techDiv); // Append the new tech item to the section
                        });
                    })
                    .catch(error => console.error('Error loading technology data:', error));

                // Fetch the services content
                fetch(`data/${lang}/services.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(serviceData => {
                        const portfolioSection = document.getElementById('services'); // Ensure this ID matches your HTML

                        // Update the main text for services
                        portfolioSection.querySelector('.main-text span').textContent = serviceData.portfolio.mainText.span;
                        portfolioSection.querySelector('.main-text h2').textContent = serviceData.portfolio.mainText.heading;

                        // Clear existing paragraphs in the left side container
                        const paragraphsContainer = portfolioSection.querySelector('.services-paragraphs');
                        paragraphsContainer.innerHTML = ''; // Clear existing paragraphs

                        // Create a fragment to improve performance
                        const fragment = document.createDocumentFragment();

                        // Add new paragraphs and append them to the fragment
                        serviceData.portfolio.introduction.forEach(paragraph => {
                            const p = document.createElement('p');
                            p.style.textAlign = "justify"; // You can adjust the styling as needed
                            p.textContent = paragraph;
                            fragment.appendChild(p);
                        });

                        // Insert the new paragraphs into the paragraphs container (left side)
                        paragraphsContainer.appendChild(fragment); // Append paragraphs to the left side container

                        // Update portfolio items
                        const gallery = portfolioSection.querySelector('.portfolio-gallery');
                        gallery.innerHTML = ''; // Clear existing items

                        serviceData.portfolio.portfolioItems.forEach(item => {
                            const div = document.createElement('div');
                            div.classList.add('port-box');
                            div.innerHTML = `
        <div class="port-image">
          <img src="${item.image}" alt="Error to load the Pic">
        </div>
        <div class="port-content">
          <h3>${item.title}</h3>
          <p>${item.description}</p>
        </div>
      `;
                            gallery.appendChild(div);
                        });

                        console.log('Services content updated for language:', lang);
                    })
                    .catch(error => console.error('Error loading services data:', error));


                // Fetch offers data
                fetch(`data/${lang}/our-offers.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        // Update offers title and description
                        document.getElementById('offersTitle').textContent = data.offers.title;
                        document.getElementById('offersDescription').textContent = data.offers.description;

                        // Update offers items
                        const firstHalfOffers = document.getElementById('firstHalfOffers');
                        const secondHalfOffers = document.getElementById('secondHalfOffers');
                        firstHalfOffers.innerHTML = ''; // Clear the first half items
                        secondHalfOffers.innerHTML = ''; // Clear the second half items

                        data.offers.items.forEach((offer, index) => {
                            const listItem = `
                <li class="first-ul-li">
                    <div class="slidetitle">
                        <span>${offer.title}</span>
                    </div>
                    <p class="description">${offer.description}</p>
                    <a href="${offer.link}">
                        <img src="${offer.image}" alt="${offer.title}" />
                    </a>
                </li>
            `;
                            if (index < 4) {
                                firstHalfOffers.innerHTML += listItem; // First half
                            } else {
                                secondHalfOffers.innerHTML += listItem; // Second half
                            }
                        });

                        // After updating, reapply your hover functionality
                        applyHoverFunctionality();

                        console.log('Offers content updated for language:', lang);
                    })
                    .catch(error => console.error('Error loading offers data:', error));



                fetch(`data/${lang}/about-us.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        const aboutSection = document.getElementById('about-us');

                        // Update main text (title and subtitle)
                        aboutSection.querySelector('#aboutSubtitle').textContent = data.mainText.subtitle; // Update subtitle
                        aboutSection.querySelector('#aboutTitle').textContent = data.mainText.title; // Update title

                        // Update About Us content
                        aboutSection.querySelector('#aboutBigHeading').textContent = data.aboutContent.bigHeading;

                        const descriptions = aboutSection.querySelectorAll('.left-column p');
                        data.aboutContent.description.forEach((desc, index) => {
                            descriptions[index].textContent = desc; // Update descriptions
                        });

                        // Update right column content
                        aboutSection.querySelector('#aboutHistoryTitle').textContent = data.aboutContent.history.title;
                        aboutSection.querySelector('#aboutHistoryText').textContent = data.aboutContent.history.text;

                        aboutSection.querySelector('#aboutWorkTitle').textContent = data.aboutContent.work.title;
                        aboutSection.querySelector('#aboutWorkText').textContent = data.aboutContent.work.text;

                        aboutSection.querySelector('#aboutDevelopmentTitle').textContent = data.aboutContent.development.title;
                        aboutSection.querySelector('#aboutDevelopmentText').textContent = data.aboutContent.development.text;

                        aboutSection.querySelector('#aboutIdealogyFranceTitle').textContent = data.aboutContent.idealogyFrance.title;
                        aboutSection.querySelector('#aboutIdealogyFranceText').textContent = data.aboutContent.idealogyFrance.text;
                    })
                    .catch(err => console.error(err));

                // Fetch the Careers JSON file based on selected language
                fetch(`data/${lang}/careers.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        const careersSection = document.getElementById('careers-section');

                        // Update Careers content
                        careersSection.querySelector('.careers-image img').src = data.careersContent.image; // Update image
                        careersSection.querySelector('#careersHeading').textContent = data.careersContent.heading; // Update heading
                        careersSection.querySelector('.light-text').textContent = data.careersContent.intro.lightText; // Update lightText
                        careersSection.querySelector('.normal-text').textContent = data.careersContent.intro.normalText; // Update normalText

                        // Update the positions list
                        const positionList = careersSection.querySelector('ul');
                        positionList.innerHTML = ''; // Clear the existing list
                        data.careersContent.positions.forEach(position => {
                            const listItem = document.createElement('li');
                            listItem.textContent = position;
                            positionList.appendChild(listItem); // Append new positions
                        });
                    })
                    .catch(err => console.error(err));

                // Fetch footer data
                fetch(`data/${lang}/footer.json?${new Date().getTime()}`)
                    .then(response => response.json())
                    .then(data => {
                        // Update footer content
                        document.getElementById('footerContent').innerHTML = `
                        ${data.copyright}<br>${data.poweredBy}<span>${data.span}</span>
                    `;

                        // Update footer logos
                        const footerLogos = document.getElementById('footerLogos');
                        footerLogos.innerHTML = ''; // Clear current logos
                        data.logoLinks.forEach(logo => {
                            footerLogos.innerHTML += `
                            <a href="${logo.url}" target="_blank">
                                <img src="${logo.image}" alt="${logo.alt}">
                            </a>
                        `;
                        });

                        console.log('Footer content updated for language:', lang);
                    })
                    .catch(error => console.error('Error loading footer data:', error));

            }

            // Load initial content based on detected language
            loadContent(currentLang);


            // Language switcher button click event
            langButton.addEventListener('click', function() {
                currentLang = langButton.getAttribute('data-lang'); // Get the next language to switch to
                loadContent(currentLang); // Load content for the new language

            });

            // Initial content load
            loadContent(currentLang);
        });
    </script>


    <!-- Fade In Effects for images Script -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logos = document.querySelectorAll('.fnc-slide__logo'); // Select all logos
            const slides = document.querySelectorAll('.fnc-slide'); // Select all slides

            // function removeClasses(logo, animations) {
            //   logo.classList.remove(...animations);
            // }

            // function addClasses(logo, animations) {
            //   logo.classList.add(...animations);
            // }

            function animateLogos(index) {
                logos.forEach((logo, i) => {
                    const animations = {
                        0: ['zoom-in'],
                        1: ['zoom-in'],
                        2: ['zoom-in'],
                        3: ['zoom-in'],
                        4: ['zoom-in'],
                        5: ['zoom-in'],
                        6: ['zoom-in'],
                        7: ['zoom-in'],
                        8: ['zoom-in'],
                        9: ['zoom-in']
                    };

                    const exitAnimations = ['zoom-in'];
                    removeClasses(logo, exitAnimations);

                    // Apply animations to each logo based on index
                    addClasses(logo, animations[i % Object.keys(animations).length]);
                    setTimeout(() => {
                        removeClasses(logo, exitAnimations);
                    }, 2000); // Adjust timing as needed for your animation length
                });
            }

            function nextLogoAnimation() {
                animateLogos();
                goToNextSlide();
            }

            setInterval(nextLogoAnimation, 8000); // Adjust timing to match your slide transition interval

            nextLogoAnimation();
        });
    </script>

    <!-- for landscape/portrait resize in rotate mode n devices -->
    <script>
        window.addEventListener("resize", function() {
            // You can add logic here if needed
            // For example, you can adjust styles based on the window width
            if (window.innerWidth > window.innerHeight) {
                // Landscape orientation
                document.body.classList.add('landscape');
            } else {
                // Portrait orientation
                document.body.classList.remove('landscape');
            }
        });
    </script>


    <!-- script for slider and contents animations effects -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const navBgs = document.querySelectorAll('.fnc-nav__bg');
            const controls = document.querySelectorAll('.fnc-nav__control');
            const progressBars = document.querySelectorAll('.fnc-nav__control-progress'); // Select progress bars
            const slides = document.querySelectorAll('.fnc-slide'); // Select slides for heading/subheading animations
            const logos = document.querySelectorAll(".fnc-slide__logo"); // Select all logos


            let currentIndex = 0; // Track the current set of visible buttons
            let currentSlideIndex = 0; // Track the current slide
            const buttonsPerSlide = 4; // Number of buttons to show at a time
            const slideDuration = 8000; // Slide duration (5 seconds)
            let slideInterval;

            // Helper functions to add/remove classes
            function removeClasses(logo, animations) {
                logo.classList.remove(...animations);
            }

            function addClasses(logo, animations) {
                logo.classList.add(...animations);
            }

            function animateLogos(index) {
                logos.forEach((logo, i) => {
                    const animations = ['zoom-in']; // Define the animations for each logo
                    removeClasses(logo, animations);
                    addClasses(logo, animations); // Apply animations

                    setTimeout(() => {
                        removeClasses(logo, animations); // Remove after a set time
                    }, 2000); // Adjust this timing if needed
                });
            }


            // ---- First Script Functionality ----
            function updateBackgroundButtons() {
                const totalButtons = navBgs.length;
                const totalSlides = Math.ceil(totalButtons / buttonsPerSlide);
                const offset = (currentIndex * 100) / totalSlides; // Calculate offset based on currentIndex
            }

            function resetProgressBars() {
                progressBars.forEach((progressBar) => {
                    progressBar.style.transform = 'scaleX(0)';
                    progressBar.style.transition = 'none'; // Temporarily remove the transition effect
                });
            }

            function startProgressBar(index) {
                const progressBar = controls[index].querySelector('.fnc-nav__control-progress');
                setTimeout(() => {
                    progressBar.style.transition = `transform ${slideDuration}ms linear`; // Correct slide duration
                    progressBar.style.transform = 'scaleX(1)'; // Start the progress bar
                }, 50); // Small delay to ensure the reset is properly applied
            }

            function updateVisibleButtons() {
                const totalButtons = controls.length; // Get the total number of controls
                controls.forEach((control, index) => {
                    if (window.innerWidth > 761) {
                        control.style.display = 'block'; // Show all buttons for large screens
                    } else {
                        // Correct condition for showing buttons
                        if (index >= currentIndex * buttonsPerSlide && index < (currentIndex + 1) * buttonsPerSlide) {
                            control.style.display = 'block'; // Show buttons in the current set
                        } else {
                            control.style.display = 'none'; // Hide the rest
                        }
                    }
                });

                // ** Reset and Start Progress for the First Button in the New Set **
                const firstVisibleButtonIndex = currentIndex * buttonsPerSlide;
                resetProgressBars(); // Ensure all progress bars are reset
                startProgressBar(firstVisibleButtonIndex); // Start the progress bar for the first button in the new set
            }


            function goToNextSet() {
                const totalButtons = navBgs.length;
                const totalSlides = Math.ceil(totalButtons / buttonsPerSlide);

                if (currentIndex < totalSlides - 1) {
                    currentIndex++;
                } else {
                    currentIndex = 0; // Reset to the first set when the last set is reached
                }

                updateVisibleButtons(); // Update visible buttons
                updateBackgroundButtons(); // Update background buttons
            }

            // Activate the first slide when the page loads
            function activateFirstSlide() {
                controls[0].classList.add('m--active-control'); // Mark the first control as active
                setTimeout(() => {
                    activateSlide(0); // Trigger the animations for the first slide with a slight delay
                }, 100); // Add a slight delay to ensure all elements are ready
            }


            // Function to reset and trigger animations on the current slide
            function activateSlide(index) {
                slides.forEach((slide, i) => {
                    // Remove active class and hide slides
                    slide.classList.remove('m--active-slide', 'fade-in');
                    slide.classList.add('fade-out');


                    const heading = slide.querySelector('.fnc-slide__heading');
                    const subheading = slide.querySelector('.fnc-slide__subheading');

                    heading.classList.remove('active');
                    subheading.classList.remove('active');
                    slide.style.opacity = '0'; // Hide slide
                });

                // Force reflow to reset animations
                void slides[index].offsetWidth;


                // Add active class and fade-in effect to the current slide
                slides[index].classList.remove('fade-out');

                // Add a slight delay before showing the slide to ensure the fade-in effect applies properly
                setTimeout(() => {
                    slides[index].classList.add('m--active-slide', 'fade-in');
                    slides[index].style.opacity = '1'; // Show slide

                    const activeHeading = slides[index].querySelector('.fnc-slide__heading');
                    const activeSubheading = slides[index].querySelector('.fnc-slide__subheading');

                    // Reset and reapply animations
                    setTimeout(() => {
                        activeHeading.classList.add('active');
                    }, 700);

                    setTimeout(() => {
                        activeSubheading.classList.add('active');
                    }, 1000);
                }, 100); // Adding a short delay before fade-in to avoid instant flashing

                currentSlideIndex = index; // Update the current index
                // Trigger logo animation immediately after slide is active
                // animateLogos(index);
            }


            function goToNextSlide() {
                resetProgressBars();
                controls.forEach((btn) => btn.classList.remove('m--active-control'));

                currentSlideIndex++;
                if (currentSlideIndex >= navBgs.length) {
                    currentSlideIndex = 0; // Loop back to the first slide
                }

                controls[currentSlideIndex].classList.add('m--active-control');
                startProgressBar(currentSlideIndex);

                activateSlide(currentSlideIndex); // Trigger heading/subheading animations

                // Trigger logo animation after the slide is fully visible
                setTimeout(() => {
                    animateLogos(currentSlideIndex);
                }, 200); // Small delay to sync with slide fade-in

                // Go to next set of buttons if needed
                if (currentSlideIndex >= (currentIndex + 1) * buttonsPerSlide) {
                    goToNextSet();
                }
                // If at the start of the list, loop back to the first set
                if (currentSlideIndex === 0) {
                    currentIndex = 0;
                    updateVisibleButtons();
                }
            }

            function startSlideProgression() {
                slideInterval = setInterval(goToNextSlide, slideDuration);
            }

            controls.forEach((control, index) => {
                control.addEventListener('click', () => {
                    clearInterval(slideInterval); // Stop auto progression

                    controls.forEach((btn) => btn.classList.remove('m--active-control'));
                    control.classList.add('m--active-control');

                    resetProgressBars(); // Reset progress bars before manually selecting

                    currentSlideIndex = index;

                    currentIndex = Math.floor(index / buttonsPerSlide); // Update current index
                    updateVisibleButtons();
                    updateBackgroundButtons();

                    startProgressBar(currentSlideIndex);
                    activateSlide(currentSlideIndex);

                    // Trigger the logo animation immediately after manual selection
                    // animateLogos(currentSlideIndex);

                    startSlideProgression(); // Restart auto progression
                });
            });

            updateVisibleButtons();
            updateBackgroundButtons();
            startSlideProgression();

            const nextButton = document.querySelector('.next-button');
            const prevButton = document.querySelector('.prev-button');

            if (nextButton) {
                nextButton.addEventListener('click', goToNextSet);
            }

            if (prevButton) {
                prevButton.addEventListener('click', () => {
                    currentIndex = currentIndex > 0 ? currentIndex - 1 : Math.ceil(navBgs.length / buttonsPerSlide) - 1;
                    updateVisibleButtons();
                    updateBackgroundButtons();
                });
            }


            activateFirstSlide(); // Ensure the first slide is activated on load
        });
    </script>

    <!-- script for offer's slides -->

    <script>
        // Function to reapply hover functionality
        function applyHoverFunctionality() {
            const main1 = document.querySelector('.main1');
            const firstUl = main1.querySelector('ul:first-of-type'); // Only target the first ul
            const firstListItem = firstUl.querySelector('li:first-child');
            const slideTitle = firstListItem.querySelector('.slidetitle');
            const description = firstListItem.querySelector('.description');

            // Function to show the title and description of the first list item
            function showFirstItemDetails() {
                slideTitle.style.opacity = '1';
                description.style.opacity = '1';
            }

            // Function to hide the title and description of the first list item
            function hideFirstItemDetails() {
                slideTitle.style.opacity = '1';
                description.style.opacity = '0';
            }

            // Mouse enter event for the main container
            main1.addEventListener('mouseenter', () => {
                hideFirstItemDetails();
            });

            // Mouse leave event for the main container
            main1.addEventListener('mouseleave', () => {
                hideFirstItemDetails();
            });

            // Mouse move event for the document
            document.addEventListener('mousemove', (event) => {
                const {
                    target
                } = event;

                // If cursor is not on any of the list items
                if (!target.closest('ul')) {
                    document.body.classList.add('body-no-hover');
                    showFirstItemDetails();
                } else {
                    document.body.classList.remove('body-no-hover');
                    // Hide description only if not on the first list item
                    if (!firstListItem.contains(target)) {
                        hideFirstItemDetails();
                    }
                }
            });

            // Ensure first item shows details on hover
            firstListItem.addEventListener('mouseenter', showFirstItemDetails);
            firstListItem.addEventListener('mouseleave', hideFirstItemDetails);

            // Target all other UL lists for normal behavior
            const allUlLists = document.querySelectorAll('.main1 ul');
            allUlLists.forEach((ul, index) => {
                if (index > 0) { // Skip first UL list
                    const listItems = ul.querySelectorAll('li');
                    listItems.forEach((li) => {
                        li.addEventListener('mouseenter', () => {
                            // Responsive width based on screen size
                            const screenWidth = window.innerWidth;
                            if (screenWidth >= 7680) {
                                li.style.width = '2575px';
                            } else if (screenWidth >= 3840 && screenWidth < 7680) {
                                li.style.width = '1240px';
                            } else if (screenWidth >= 1920 && screenWidth < 3840) {
                                li.style.width = '750px';
                            } else {
                                li.style.width = '610px';
                            }

                            // Set all other elements in the list to responsive width based on screen size
                            listItems.forEach((otherLi) => {
                                if (otherLi !== li) {
                                    if (screenWidth >= 7680) {
                                        otherLi.style.width = '570px';
                                    } else if (screenWidth >= 3840 && screenWidth < 7680) {
                                        otherLi.style.width = '300px';
                                    } else if (screenWidth >= 1920 && screenWidth < 3840) {
                                        otherLi.style.width = '130px';
                                    } else {
                                        otherLi.style.width = '100px';
                                    }
                                }
                            });
                        });

                        li.addEventListener('mouseleave', () => {
                            // Reset all elements to their default width based on screen size
                            const screenWidth = window.innerWidth;
                            listItems.forEach((otherLi) => {
                                if (screenWidth >= 7680) {
                                    otherLi.style.width = '800px';
                                } else if (screenWidth >= 3840 && screenWidth < 7680) {
                                    otherLi.style.width = '350px';
                                } else if (screenWidth >= 1920 && screenWidth < 3840) {
                                    otherLi.style.width = '155px';
                                } else {
                                    otherLi.style.width = '135px';
                                }
                            });
                        });
                    });
                }
            });
        }

        // Initial application of hover functionality on DOMContentLoaded
        document.addEventListener('DOMContentLoaded', applyHoverFunctionality);
    </script>






    <script src="assets/js/slider-script.js"></script>
    <script src="assets/js/script.js"></script>

</body>

</html>