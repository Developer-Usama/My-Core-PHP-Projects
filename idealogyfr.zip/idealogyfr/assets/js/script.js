// Select all the menu links and sections
let menuLi = document.querySelectorAll('header ul li a');
let sections = document.querySelectorAll('section');

function activeMenu() {
  let len = sections.length;
  
  // Check the current scroll position and match it with section offsetTop
  while (--len && window.scrollY + 97 < sections[len].offsetTop) {}

  // Remove 'active' class from all menu links
  menuLi.forEach(sec => sec.classList.remove("active"));

  // Add 'active' class to the matched section's corresponding link
  if (menuLi[len]) {
    menuLi[len].classList.add("active");
  }
}

// Call the function on page load and on scroll
activeMenu();
window.addEventListener("scroll", () => {
  activeMenu();
  // Add the progress bar scroll calculation here to ensure it's not impacted
  updateProgressBar();
});


// Sticky navbar 
const header = document.querySelector("header");
window.addEventListener("scroll", function () {
  header.classList.toggle("sticky", window.scrollY > 50);
});

// Toggle bar for small screens
let menuIcon = document.querySelector("#menu-icon");
let navlist = document.querySelector(".navlist");

menuIcon.addEventListener("click", function () {
  menuIcon.classList.toggle("bx-x");
  navlist.classList.toggle("open");
});

window.onscroll = () => {
  menuIcon.classList.remove("bx-x");
  navlist.classList.remove("open");
};

// Progress bar functionality
function updateProgressBar() {
  var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
  var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  var scrolled = (winScroll / height) * 100;
  document.getElementById("myBar").style.width = scrolled + "%";
}

// Call progress bar function on page load as well
updateProgressBar();


// parallax 
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show-items");
        } else {
            entry.target.classList.remove("show-items");
        }
    });
});

const scrollScale = document.querySelectorAll(".scroll-scale");
scrollScale.forEach((el) => observer.observe(el));

const scrollBottom = document.querySelectorAll(".scroll-bottom");
scrollBottom.forEach((el) => observer.observe(el));

const scrollTop = document.querySelectorAll(".scroll-top");
scrollScale.forEach((el) => observer.observe(el));



// pagination functionality for portfolio section
const prevButton = document.querySelector('.prev-button');
const nextButton = document.querySelector('.next-button');
const projectBoxes = document.querySelectorAll('.port-box');
const boxesPerPage = 4;
let currentPage = 0;

function showBoxes(page) {
    const startIndex = page * boxesPerPage;
    const endIndex = startIndex + boxesPerPage;

    projectBoxes.forEach((box, index) => {
        if (index >= startIndex && index < endIndex) {
            box.style.display = 'block';
        } else {
            box.style.display = 'none';
        }
    });
}

function handlePageChange(change) {
    currentPage += change;
    if (currentPage < 0) {
        currentPage = 0;
    } else if (currentPage >= Math.ceil(projectBoxes.length / boxesPerPage)) {
        currentPage = Math.floor(projectBoxes.length / boxesPerPage);
    }
    showBoxes(currentPage);
}

prevButton.addEventListener('click', () => {
    handlePageChange(-1);
});

nextButton.addEventListener('click', () => {
    handlePageChange(1);
});

// Initial display
showBoxes(currentPage);

