<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>TEST</title>

  <link rel="stylesheet" type="text/css" href="assets/css/main-css.css">


</head>