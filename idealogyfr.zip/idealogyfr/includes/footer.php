<!-- footer section ----------------------------->
<footer class="footer">
    <p class="scroll-scale">Copyright &copy; 2008-2024 || All Rights Reserved. <br style="text-align: center;"> Powored by <span> IDEALOGY </span> </p>

    <!-- Logo Container -->
    <div class="footer-logos">
        <a href="https://www.justsigns.tv" target="_blank"><img src="./assets/images/justsigns.png" alt="Logo 1"></a>
        <a href="https://www.justselect.com" target="_blank"><img src="./assets/images/justselect.png" alt="Logo 2"></a>
        <a href="https://www.justdriver.online" target="_blank"><img src="./assets/images/justdriver.png" alt="Logo 3"></a>

        <!-- Add up to 5 logos -->
    </div>
</footer>