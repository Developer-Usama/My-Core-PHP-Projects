<?php
// Assume that the default language is always French ('fr'), unless specified otherwise in URL or by user preference
$defaultLang = 'fr'; // Set French as the default language

// If you want to detect the user's language preference from the URL or other logic, you can override this.
if (isset($_GET['lang']) && $_GET['lang'] == 'en') {
  $defaultLang = 'en'; // Switch to English if the 'lang' parameter is set to 'en'
}
?>

<!DOCTYPE html>
<html lang="<?php echo $defaultLang; ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Hreflang tags for multilingual support -->
  <link rel="alternate" hreflang="fr" href="https://idealogy.fr/fr">
  <link rel="alternate" hreflang="en" href="https://idealogy.fr/en">
  <link rel="alternate" hreflang="x-default" href="https://idealogy.fr<?php echo ($defaultLang == 'fr') ? '/fr' : '/en'; ?>">

  <?php if ($defaultLang == 'fr') { ?>
  <meta name="title" content="IDEALOGY | Création de sites web | Applications | Logiciels" lang="fr">
    <meta name="description" content="Idealogy offre des services complets : design de sites web mobiles, développement d'applications, solutions eCommerce et marketing digital." lang="fr">
    <meta name="keywords" content="idealogy, Conception de sites web, Développement web, Développement d'applications mobiles, Solutions logicielles sur mesure, Sites eCommerce" lang="fr">
  <?php } ?>
  <?php if ($defaultLang == 'en') { ?>
<meta name="title" content="IDEALOGY | Website Creation | Applications | Software" lang="en">
    <meta name="description" content="Idealogy offers a complete range of services, including mobile-friendly, responsive website design and app development, eCommerce solutions, digital marketing." lang="en">
    <meta name="keywords" content="idealogy, Website design, Web development, ecommerce, mobile site, responsive web design" lang="en">
  <?php } ?>

  <!-- Dynamic Title Tag -->
  <title><?php
    if ($defaultLang == 'fr') {
      echo 'IDEALOGY | Création de sites web | Applications | Logiciels';
    } else {
      echo 'IDEALOGY | Website Creation | Applications | Software';
    }
    ?></title>

  <!-- link for favicon -->
  <link rel="icon" type="image/png" href="assets/images/favicon/favicon-48x48.png" sizes="48x48" />
  <link rel="icon" type="image/svg+xml" href="assets/images/favicon/favicon.svg" />
  <link rel="shortcut icon" href="assets/images/favicon/favicon.ico" />
  <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicon/apple-touch-icon.png" />
  <link rel="manifest" href="assets/images/favicon/site.webmanifest" />


  <!-- Font for slider's titles -->
  <link rel="stylesheet" href="assets/fonts/roboto-fonts.css">

  <!-- Font for slider's subtitles  -->
  <link rel="stylesheet" href="assets/fonts/monserrat-fonts.css">

  <!-- link for main css styles -->
  <link rel="stylesheet" type="text/css" href="assets/css/main-css.css">

  <!-- link to css.scss file -->
  <link rel="stylesheet" href="assets/css/css.css">

  <!-- fonts poppins -->
  <link rel="stylesheet" type="text/css" href="assets/fonts/poppins-fonts.css">


  <!-- link for box icons -->
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <!-- nonito fonts -->
  <link rel="stylesheet" href="./assets/fonts/ninito-fonts.css">

</head>