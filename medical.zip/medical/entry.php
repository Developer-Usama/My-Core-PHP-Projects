<?php require_once('Connections/conn.php'); ?>
<?php
include 'Header.php';

?>
<?php

// Start a session or resume the existing session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['MM_Username'])) {
  // Redirect the user to the login page
  header("Location: index.php"); // Replace 'login.php' with your actual login page
  exit(); // Stop executing the current script
}

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF'] . "?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")) {
  $logoutAction .= "&" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) && ($_GET['doLogout'] == "true")) {
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);

  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")
{
  // $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
?>


<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }


  textarea {
    width: 100%;
    height: 80px;
    padding: 5px 15px;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: .5rem;
    background-color: #ffffff;
    font-size: 13px;
    resize: none;

  }

  .style2 {
    color: #FFFFFF
  }



  input[type=text],
  select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
  }

  input[type=submit] {
    width: 50%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px auto;
    display: block;
    font-weight: bold;
    align-items: center;
    justify-content: center;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  input[type=submit]:hover {
    background-color: #45a049;
  }


  .style3 {
    font-family: Arial, Helvetica, sans-serif
  }


  body {
    font-family: Arial, sans-serif;
    background-image: url('background.png');
  }

  form {
    background-color: #e3f9fa;
    box-shadow: black inset 0px 1px 2px;
    border-radius: 1rem;
    padding: 1rem;
    max-width: 70%;
    margin: 1rem auto;
  }

  table {
    width: 100%;
  }

  td {
    padding: 0;
    /* margin: 0; */
  }

  input[type="text"],
  input[type="number"],
  select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 0.5rem;
  }

  .radio-group {
    display: flex;
    gap: 1rem;
    font-size: 12px;
  }

  .checkbox-group {
    display: flex;
    flex-wrap: wrap;
    font-size: 12px;
    width: 100%;
    justify-content: space-between;
  }

  .checkbox-row {
    width: calc(33.33% - 1rem);
    margin-bottom: 0.5rem;
    box-sizing: border-box;
  }

  #total,
  #finalAmount {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: 0.5rem;
    font-weight: bold;
  }


  /* Responsive Design */
  @media (max-width: 768px) {
    form {
      max-width: 100%;
    }

    .style1 {
      font-size: 20px;
    }

    .checkbox-row {
      width: calc(50% - 1rem);
    }
  }

  @media (max-width: 480px) {
    .checkbox-row {
      width: 100%;
    }

  }
</style>






<?php
// require_once('Connections/conn.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {


  // Retrieve the selected checkbox values and their prices
  $selectedProcedures = isset($_POST['procedure']) ? $_POST['procedure'] : array();
  $procedureValues = array();

  foreach ($selectedProcedures as $procedure) {
    $price = $_POST[$procedure . '_price'];
    $procedureValues[] = "$procedure";
  }

  // Check if the "Other" checkbox is selected and has a price and details
  if (isset($_POST['other']) && $_POST['other'] == 'Other') {
    $otherDetails = $_POST['other_details']; // Capture the details for the "Other" procedure
    $otherPrice = isset($_POST['other_price']) ? intval($_POST['other_price']) : 0;

    if (
      !empty($otherDetails) && $otherPrice > 0
    ) {
      if (!empty($procedureValuesString)) {
        $procedureValuesString .= ", ";
      }
      $procedureValuesString .= "Other ($otherDetails)"; // Append the Other procedure details to the existing procedure string
      $total += $otherPrice; // Add the Other procedure price to the total
    }
  } else {
    $otherDetails = ''; // Set it to an empty string if "Other" is not selected
  }



  // Combine the procedure values into a single string
  $procedureValuesString = implode(', ', $procedureValues);




  // Calculate total, discount, and final amount
  // $total = 0;
  $total = $_POST['total'];

  $discount = isset($_POST['discount']) ? intval($_POST['discount']) : 0;

  foreach ($selectedProcedures as $procedure) {
    $price = $_POST[$procedure . '_price'];
    $total += $price;
  }

  $finalAmount = $total - $discount;

  $stmt = $conn->prepare("INSERT INTO registration (fname, lname, gender, age, status, phone, dob, address, `procedure`, visit, total, discount, finalAmount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");


  if ($stmt === false) {
    die("Error in SQL statement: " . $conn->error);
  }


  // Now bind parameters and execute the statement
  $stmt->bind_param("sssissssssiid", $fname, $lname, $gender, $age, $status, $phone, $dob, $address, $procedureValuesString, $visit, $total, $discount, $finalAmount);


  // Set values for the parameters
  // Set values for the parameters
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $gender = $_POST['gender'];
  $age = $_POST['age'];
  $status = $_POST['status'];
  $phone = $_POST['phone'];
  $dob = $_POST['dob'];
  $address = $_POST['address'];
  $visit = isset($_POST['visit']) ? $_POST['visit'] : ''; // Capture the selected visit value



  $total = $total; // Keep the total value as it is
  $discount = $_POST['discount'];
  $finalAmount = $finalAmount;




  // Execute the statement
  if ($stmt->execute()) {
    // Success
    header('Location: Records.php');
  } else {
    // Error
    die("Error inserting record: " . $stmt->error);
  }

  // Close the statement and the database connection
  $stmt->close();
  $conn->close();
}
?>

<!-- Your HTML form remains unchanged -->
<!-- The JavaScript code for calculating the total and final amount is already included in your code -->




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />


  <title>INU Dental Clinic</title>
  <style type="text/css">
    <!--
    .style1 {
      margin-top: 0px;
      padding-top: .5rem;
      font-size: 32px
    }

    </style><script type="text/JavaScript">< !-- function MM_findObj(n, d) {
      //v4.01
      var p,
      i,
      x;
      if( !d) d=document;

      if((p=n.indexOf("?"))>0&&parent.frames.length) {
        d=parent.frames[n.substring(p+1)].document;
        n=n.substring(0, p);
      }

      if( !(x=d[n])&&d.all) x=d.all[n];
      for (i=0; !x&&i<d.forms.length; i++) x=d.forms[i][n];
      for(i=0; !x&&d.layers&&i<d.layers.length; i++) x=MM_findObj(n, d.layers[i].document);
      if( !x && d.getElementById) x=d.getElementById(n);
      return x;
    }

    function MM_validateForm() {
      //v4.0
      var i,
      p,
      q,
      nm,
      test,
      num,
      min,
      max,
      errors='',
      args=MM_validateForm.arguments;

      for (i=0; i<(args.length-2); i+=3) {
        test=args[i+2];
        val=MM_findObj(args[i]);

        if (val) {
          nm=val.name;

          if ((val=val.value) !="") {
            if (test.indexOf('isEmail') !=-1) {
              p=val.indexOf('@');
              if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
            }

            else if (test !='R') {
              num=parseFloat(val);
              if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';

              if (test.indexOf('inRange') !=-1) {
                p=test.indexOf(':');
                min=test.substring(8, p);
                max=test.substring(p+1);
                if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
              }
            }
          }

          else if (test.charAt(0)=='R') errors+='- '+nm+' is required.\n';
        }
      }

      if (errors) alert('The following error(s) occurred:\n' +errors);
      document.MM_returnValue=(errors=='');
    }

    //
    -->
  </script>





</head>


<body>
  <div align="center">
    <p class="style1"><img src="logo.png" width="120" height="120" /></p>
    <p class="style1">IQRA National University Peshawar<br /> </p>
    <p class="head" style="color:#45a049; font-size:30px; margin-top:1rem;"> Dental Clinic Managemant System <br>
      Patient Registration Form </p>
  </div>

  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="50%" align="center">
      <tr valign="baseline">
        <td><span class="style3">Patient First Name:</span> </td>
        <td><span class="style3">Patient Last Name: </span></td>
        <td><span class="style3">Patient Age:</span></td>
      </tr>
      <tr valign="baseline">
        <td><input type="text" name="fname" value="" placeholder="First Name" size="44" /></td>
        <td><input type="text" name="lname" value="" placeholder="Last Name" size="44" /></td>
        <td><input type="text" name="age" value="" placeholder="Age" size="44" /></td>

      </tr>
      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Patient Phone:</span></td>
        <td><span class="style3">Patient Status:</span></td>
        <td colspan="2"><span class="style3">Patient Date of Birth: </span></td>


      </tr>
      <tr valign="baseline">
        <td><input type="text" name="phone" value="" placeholder="Phone" size="44" /></td>
        <td><select name="status">
            <option value="INU Student" <?php if (!(strcmp("INU Student", ""))) {
                                          echo "SELECTED";
                                        } ?>>INU Student</option>
            <option value="INU Faculty" <?php if (!(strcmp("INU Faculty", ""))) {
                                          echo "SELECTED";
                                        } ?>>INU Faculty</option>
            <option value="INU Staff" <?php if (!(strcmp("INU Staff", ""))) {
                                        echo "SELECTED";
                                      } ?>>INU Staff</option>
            <option value="Outsider" <?php if (!(strcmp("Outsider", ""))) {
                                        echo "SELECTED";
                                      } ?>>Outsider</option>
            <option value="Free Medical Camp" <?php if (!(strcmp("Free Medical Camp", ""))) {
                                                echo "SELECTED";
                                              } ?>>Free Dental Camp</option>
          </select></td>

        <td colspan="2"><input style="padding: 12px 20px; width:100%; border-radius:5px; border:none;" type="date" name="dob" value="" placeholder="Date of Birth" size="32"></td>

      </tr>
      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Patient Gender:</span></td>
        <td colspan="2"><span class="style3">Patient Visit: </span></td>

      </tr>
      <tr valign="baseline">
        <td style="font-size: 12px;"><input name="gender" type="radio" value="Male" checked="checked" />
          <span class="style3">Male</span>
          <input type="radio" name="gender" value="Female" />
          <span class="style3">Female</span>
        </td>

        <td style="font-size: 12px;" colspan="2"><input name="visit" type="radio" value="First Visit" checked="checked" />
          <span class="style3"> First Visit</span>
          <input type="radio" name="visit" value="Second Visit" />
          <span class="style3">Second Visit</span>
          <input type="radio" name="visit" value="Third Visit" />
          <span class="style3">Third Visit</span>
          <input type="radio" name="visit" value="Forth Visit" />
          <span class="style3"> Forth Visit</span>
          <input type="radio" name="visit" value="Fifith Visit" />
          <span class="style3">Fifith Visit</span>
        </td>

      </tr>


      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>

      <tr valign="baseline">
        <td colspan="2"><span class="style3">Patient Address:</span></td>
      </tr>
      <tr valign="baseline">
        <td colspan="2"><textarea name="address" placeholder="Patient Address" cols="100" rows="5"></textarea> </td>
      </tr>


      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>

      <tr valign="baseline">
        <td colspan="2"><span class="style3">Procedures:</span></td>
      </tr>

      <tr valign="baseline">
        <td colspan="2">
          <div class="checkbox-group">
            <div class="checkbox-row">
              <label for="extraction">
                <input type="checkbox" name="procedure[]" id="extraction" value="Extraction" data-price="1000"> Extraction (Rs 1,000)
              </label>
            </div>
            <div class="checkbox-row">
              <label for="composite_filling">
                <input type="checkbox" name="procedure[]" id="composite_filling" value="Composite Filling" data-price="3000"> Composite Filling - (3,000) PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="amalgam_filling">
                <input type="checkbox" name="procedure[]" id="amalgam_filling" value="Amalgam Filling" data-price="2000"> Amalgam Filling - 2,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="gic_filling">
                <input type="checkbox" name="procedure[]" id="gic_filling" value="GIC Filling" data-price="2000"> GIC Filling - 2,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="scaling_polishing">
                <input type="checkbox" name="procedure[]" id="scaling_polishing" value="Scaling and Polishing" data-price="3000"> Scaling and Polishing - 3,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="surgical_extraction">
                <input type="checkbox" name="procedure[]" id="surgical_extraction" value="Surgical Extraction" data-price="4000"> Surgical Extraction - 4,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="rct">
                <input type="checkbox" name="procedure[]" id="rct" value="RCT" data-price="3000"> RCT (Root Canal Treatment) - 3,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="pulpotomy">
                <input type="checkbox" name="procedure[]" id="pulpotomy" value="Pulpotomy" data-price="2500"> Pulpotomy - 2,500 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="bleaching">
                <input type="checkbox" name="procedure[]" id="bleaching" value="Bleaching" data-price="15000"> Bleaching - 15,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="crown">
                <input type="checkbox" name="procedure[]" id="crown" value="Crown" data-price="5000"> Crown - 5,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="zirconium_crown">
                <input type="checkbox" name="procedure[]" id="zirconium_crown" value="Zirconium Crown" data-price="15000"> Zirconium Crown - 15,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="complete_denture">
                <input type="checkbox" name="procedure[]" id="complete_denture" value="Complete Denture" data-price="20000"> Complete Denture - 20,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="implant">
                <input type="checkbox" name="procedure[]" id="implant" value="Implant" data-price="50000"> Implant (50,000) PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="partial_denture">
                <input type="checkbox" name="procedure[]" id="partial_denture" value="Partial Denture" data-price="1000"> Partial Denture - 1,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="post_and_core">
                <input type="checkbox" name="procedure[]" id="post_and_core" value="Post and Core" data-price="2000"> Post and Core - 2,000 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="pocket_dressing">
                <input type="checkbox" name="procedure[]" id="pocket_dressing" value="Pocket Dressing" data-price="1500"> Pocket Dressing - 1,500 PKR
              </label>
            </div>
            <div class="checkbox-row">
              <label for="tooth_gem">
                <input type="checkbox" name="procedure[]" id="tooth_gem" value="Tooth Gem" data-price="200"> Tooth Gem - 200 PKR per tooth
              </label>
            </div>

            <div class="checkbox-row">
              <label for="cementation">
                <input type="checkbox" name="procedure[]" id="cementation" value="cementation" data-price="1000"> Cementation- 1000 PKR per tooth
              </label>
            </div>

            <div class="checkbox-row">
              <label for="other">
                <input type="checkbox" name="procedure[]" id="other" value="Other" data-price="0"> Other
              </label>
            </div>
            <div class="checkbox-row">
              <label for="other_price">
                Other Price (PKR): <input type="number" name="other_price" id="other_price" placeholder="Enter price" oninput="calculateTotal()">
              </label>
            </div>


          </div>
        </td>
      </tr>




      <tr valign="baseline">
        <td colspan="2" valign="baseline">&nbsp;</td>
      </tr>

      <tr valign="baseline">
        <td>Total PKR:</td>
        <td>Discount PKR:</td>
        <td>Final Amount PKR:</td>
      </tr>

      <tr valign="baseline">
        <td><input type="text" id="total" name="total" value="0" readonly></td>
        <td><input type="number" id="discount" name="discount" value="0" oninput="calculateTotal()"></td>
        <td><input type="text" id="finalAmount" name="finalAmount" value="0" readonly></td>
      </tr>


      <tr valign="baseline">
        <td colspan="2" valign="baseline">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2"><input type="submit" onclick="MM_validateForm('fname','','R','lname','','R','age','','RisNum','phone','','RisNum','dob','','R');return document.MM_returnValue" value="Submit Record"></td>
      </tr>
    </table>
    <input type="hidden" name="MM_insert" value="form1">
  </form>
  <div style="display: inline-flex; flex-direction: row; align-items: flex-end; text-align: end; position: absolute; top: 34.8%; right: 14.9%;">
    <button class="btn1" style="background-color: #45a049; border: none; padding: 8px 12px; border-radius: 5px; border-top-left-radius:3rem;  align-items: center; margin: auto; display: block; margin: 2px;" align="center">
      <a style="color: white; text-decoration: none;" href="Records.php"><b>Records</b></a>
    </button>
    <button class="btn2" style="background-color: #d63031; color: white; padding: 8px 12px; border-radius: 5px; border-top-right-radius:3rem; align-items: center; border: none; margin: auto; display: block; margin: 2px;" align="center">
      <a style="color: white; text-decoration: none;" href="<?php echo $logoutAction ?>"><b>Log out</b></a>
    </button>

  </div>



</body>

</html>





/* <!-- //js for to total the values and then apply discount and  then combine total value after discount --> */
<script>
  // Function to calculate the total price
  function calculateTotal() {
    let total = 0;
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    checkboxes.forEach((checkbox) => {
      const price = parseInt(checkbox.getAttribute('data-price'));
      total += price;
    });

    // Include the "Other" price if it's entered and the checkbox is checked
    const otherCheckbox = document.getElementById('other');
    if (otherCheckbox.checked) {
      const otherPrice = parseInt(document.getElementById('other_price').value);
      if (!isNaN(otherPrice)) {
        total += otherPrice;
      }
    }

    const discount = parseInt(document.getElementById('discount').value);
    const finalAmount = total - discount;

    document.getElementById('total').value = total;
    document.getElementById('finalAmount').value = finalAmount;
  }

  // Add an event listener to all checkboxes to recalculate the total when they change
  const checkboxes = document.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', calculateTotal);
  });

  // Initialize the total when the page loads
  calculateTotal();
</script>