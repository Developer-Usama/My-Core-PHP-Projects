<?php
require_once('Connections/conn.php');
include 'Header.php';

// Start a session or resume the existing session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['MM_Username'])) {
    // Redirect the user to the login page
    header("Location: index.php"); // Replace 'login.php' with your actual login page
    exit(); // Stop executing the current script
}



// Initialize the session
if (!isset($_SESSION)) {
    session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF'] . "?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")) {
    $logoutAction .= "&" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) && ($_GET['doLogout'] == "true")) {
    // To fully log out a visitor, clear the session variables
    $_SESSION['MM_Username'] = NULL;
    $_SESSION['MM_UserGroup'] = NULL;
    $_SESSION['PrevUrl'] = NULL;
    unset($_SESSION['MM_Username']);
    unset($_SESSION['MM_UserGroup']);
    unset($_SESSION['PrevUrl']);

    $logoutGoTo = "index.php";
    if ($logoutGoTo) {
        header("Location: $logoutGoTo");
        exit;
    }
}

// Number of records per page
$recordsPerPage = 15;

// Get the current page number from the URL
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
    $currentPage = intval($_GET['page']);
} else {
    $currentPage = 1; // Default to the first page
}

// Initialize the search variable
$searchQuery = "";

// Check if a search term has been provided
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchTerm = mysql_real_escape_string($_GET['search']); // Sanitize the input

    // Modify the search query to filter by first or last name
    $searchQuery = "AND (fname LIKE '%$searchTerm%' OR lname LIKE '%$searchTerm%') ";
}

// Initialize the status filter variable
$selectedStatus = "";

// Check if a status filter has been selected
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $selectedStatus = mysql_real_escape_string($_GET['status']); // Sanitize the input

    // Modify the SQL query to filter by the selected status
    $statusFilterQuery = "AND status = '$selectedStatus' ";
} else {
    $statusFilterQuery = ""; // No status filter selected, so it's empty
}

// Initialize the month filter variable
$selectedMonth = "";

// Check if a month filter has been selected
if (isset($_GET['month']) && !empty($_GET['month'])) {
    $selectedMonth = mysql_real_escape_string($_GET['month']); // Sanitize the input

    // Modify the SQL query to filter by the selected month
    $monthFilterQuery = "AND MONTH(date) = '$selectedMonth' ";
} else {
    $monthFilterQuery = ""; // No month filter selected, so it's empty
}

// Query to retrieve total number of records with search filter and month filter
$query_TotalRecords = "SELECT COUNT(*) AS total FROM registration WHERE 1 $searchQuery $monthFilterQuery $statusFilterQuery";
$result_TotalRecords = $conn->query($query_TotalRecords);
$row_TotalRecords = $result_TotalRecords->fetch_assoc();
$totalRows_TotalRecords = $row_TotalRecords['total'];


// Calculate the total number of pages
$totalPages = ceil($totalRows_TotalRecords / $recordsPerPage);

// Calculate the offset for the query
$offset = ($currentPage - 1) * $recordsPerPage;


// Query to retrieve records with pagination and search filter and month filter
$query_Recordset1 = "SELECT * FROM registration WHERE 1 $searchQuery $monthFilterQuery $statusFilterQuery ORDER BY `date` DESC LIMIT $offset, $recordsPerPage";
$result_Recordset1 = $conn->query($query_Recordset1);

// Total number of records for the current page
$totalRows_Recordset1 = $result_Recordset1->num_rows;


// Create an array to map month numbers to month names
$monthNames = [
    '01' => 'January',
    '02' => 'February',
    '03' => 'March',
    '04' => 'April',
    '05' => 'May',
    '06' => 'June',
    '07' => 'July',
    '08' => 'August',
    '09' => 'September',
    '10' => 'October',
    '11' => 'November',
    '12' => 'December',
];

// Function to select the appropriate option in the dropdown
function isSelected($month, $selectedMonth)
{
    return $month === $selectedMonth ? 'selected' : '';
}
?>



<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* previous page styling copied */
    textarea {
        width: 100%;
        height: 150px;
        padding: 12px 20px;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        background-color: #ffffff;
        font-size: 16px;
        resize: none;
    }

    .style2 {
        color: #FFFFFF
    }

    .style3 {
        font-family: Arial, Helvetica, sans-serif;
        padding: .2rem;
        font-size: 12.5px;

    }



    /* for pagination styling */
    .pagination {
        text-align: center;
        margin-top: 20px;
    }

    .pagination-link {
        display: inline-block;
        padding: 2px 12px;
        background-color: #3498db;
        color: white;
        text-decoration: none;
        border-radius: .5rem;
        margin: 0 4px;
        cursor: pointer;
        margin-top: 10px;
    }

    .pagination-link:hover {
        background-color: #2980b9;
    }

    .pagination-link.disabled {
        background-color: #ccc;
        cursor: not-allowed;
    }

    /* Style for the table container */
    /* CSS for the table */
    .table-container {
        max-width: 99%;
        /* Adjust the width as per your requirements */
        overflow-x: auto;
        display: block;
        margin: auto;
        margin-top: 20px;
        background-color: white;
        /* Add margin from the top */
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px auto;
        border-spacing: 0;
        border-radius: .5rem;
        table-layout: fixed;
        /* Set the table layout to fixed */
    }

    th,
    td {
        width: 90px;
        border: 1px solid #ccc;
        padding: 6px;
        text-align: left;
        font-size: 13px;
        overflow: hidden;
        /* Hide overflowing content */
    }


    th {
        background-color: #3498db;
        color: #fff;
        font-weight: bold;
        font-size: 15px;
    }



    tr:nth-child(even) {
        background-color: #ccc;
    }

    tr:hover {
        background-color: #e0e0e0;
    }

    /* CSS for highlighting rows */
    .highlighted-row {
        /* background-color: yellow; */
        /* You can adjust the highlight color here */
    }

    .dropdown-option {
        border-radius: 1rem;
        padding: 5px;
        background-color: green;
        color: white;
    }

    .dropdown-options {
        margin-left: -200px;
    }
</style>

<div style="display: flex; justify-content: space-between; align-items: center; margin:0px; background-color:green; padding:5px 20px;">
    <h3 style="margin: 0; font-size:21.5px; text-align: center; color:white;">INU Dental Clinic Management System</h3>
    <div style="display: inline-flex; flex-direction: row; align-items: flex-end;">

        <button class="btn-back" style="background-color: #3498db; box-shadow: black 0px 1px 1px ; color: white; padding: 6px 12px; border-radius: .5rem; outline:none; border:none; align-items: center; margin: 5px;">
            <a style="color: white; text-decoration: none;" href="entry.php"><b>Add Record</b></a>
        </button>

        <button class="btn2" style="background-color: #e74c3c; box-shadow: black 0px 1px 1px ; color: white; padding: 6px 12px; border-radius: 5px; align-items: center; outline:none; border:none; margin: 5px;">
            <a style="color: white; text-decoration: none;" href="<?php echo $logoutAction ?>"><b>Log out</b></a>
        </button>
    </div>
</div>

<div style="padding: 1% 2% 1% 2%; display:flex; flex-direction: row; justify-content: space-between;">
    <h4 style="color: #3498db; font-size:19.5; text-decoration:underline;">Registered Patients Lists:</h4>


    <!-- Status Filter Dropdown -->
    <div class="dropdown-options">
        <select class="dropdown-option" id="statusFilter" onchange="filterRecords()">
            <option value="">All Patients</option>
            <option value="INU Student" <?php echo ($selectedStatus === 'INU Student') ? 'selected' : ''; ?>>INU Student</option>
            <option value="INU Faculty" <?php echo ($selectedStatus === 'INU Faculty') ? 'selected' : ''; ?>>INU Faculty</option>
            <option value="INU Staff" <?php echo ($selectedStatus === 'INU Staff') ? 'selected' : ''; ?>>INU Staff</option>
            <option value="Outsider" <?php echo ($selectedStatus === 'Outsider') ? 'selected' : ''; ?>>Outsider</option>
            <option value="Free Dental Camp" <?php echo ($selectedStatus === 'Free Dental Camp') ? 'selected' : ''; ?>>Free Dental Camp</option>
        </select>






        <!-- Month Filter Dropdown -->
        <select class="dropdown-option" id="monthFilter" onchange="filterRecords()">
            <option value="">All Months</option>
            <?php foreach ($monthNames as $monthNumber => $monthName) : ?>
                <option value="<?php echo $monthNumber; ?>" <?php echo isSelected($monthNumber, $selectedMonth); ?>><?php echo $monthName; ?></option>
            <?php endforeach; ?>
        </select>

    </div>


    <!-- Pagination Links -->
    <div class="">
        <?php if ($currentPage > 1) : ?>
            <a href="records.php?page=<?php echo $currentPage - 1; ?>&search=<?php echo isset($_GET['search']) ? urlencode($_GET['search']) : ''; ?>" class="pagination-link">&lt; Previous</a>
        <?php endif; ?>

        <?php if ($currentPage < $totalPages) : ?>
            <a href="records.php?page=<?php echo $currentPage + 1; ?>&search=<?php echo isset($_GET['search']) ? urlencode($_GET['search']) : ''; ?>" class="pagination-link">Next &gt;</a>
        <?php endif; ?>
    </div>


    <!-- Add the search form here -->
    <form action="records.php" method="GET">
        <input style="background-color: inherit; border:2px solid green; outline: none; padding: 5px 20px; border-top-left-radius:.5rem; border-bottom-left-radius:.5rem;" type="text" name="search" placeholder="Search by First Name" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <?php if (isset($_GET['search']) && !empty($_GET['search'])) : ?>
            <a href="records.php" style="text-decoration: none;">
                <button type="button" style=" background-color: #e74c3c; border:1px solid #e74c3c; cursor:pointer; width:70px; outline: none; padding: 6px 2px;text-align:center; color:white; margin-left:-5px; border-top-right-radius:.5rem; border-bottom-right-radius:.5rem;">Close</button>
            </a>
        <?php else : ?>
            <input style=" background-color: green; cursor:pointer; border:1px solid green; width:70px; outline: none; padding: 6px 2px;text-align:center; color:white; margin-left:-5px; border-top-right-radius:.5rem; border-bottom-right-radius:.5rem;" type="submit" value="Search">
        <?php endif; ?>
    </form>
</div>


<!-- function for to highlight the filtered records -->
<?php
// Function to determine if a row should be highlighted
function shouldHighlightRow($recordDate, $selectedMonth)
{
    if (empty($selectedMonth)) {
        // If no month filter is selected, highlight all rows
        return true;
    }

    // Extract the month and year from the record date (assuming date format yyyy-mm-dd)
    $recordMonth = date('m', strtotime($recordDate));
    $recordYear = date('Y', strtotime($recordDate));

    // Compare the record's month and year with the selected month and current year
    $currentMonth = date('m');
    $currentYear = date('Y');

    return $recordMonth === $selectedMonth && $recordYear === $currentYear;
}
?>


<?php if ($totalRows_Recordset1 > 0) { ?>
    <div class="table-container">
        <table border="0" align="center" cellpadding="" class="table-striped table-hover">
            <tr style="font-weight: bold;">
                <td bgcolor="#666666"><span class="style2 style3">First Name </span></td>
                <td bgcolor="#666666"><span class="style2 style3">Last Name </span></td>
                <td bgcolor="#666666"><span class="style2 style3">Sex</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Age</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Status</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Phone</span></td>
                <td bgcolor="#666666"><span class="style2 style3">DOB</span></td>
                <td style="width: 160px; font-size:10.5px;" bgcolor="#666666"><span class="style2 style3">Address</span></td>
                <td style="width: 160px; font-size:8px;" bgcolor="#666666"><span class="style2 style3">Procedure</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Visit</span></td>
                <td style="width: 140px;" bgcolor="#666666"><span class="style2 style3">Date / Time</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Total</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Discount</span></td>
                <td bgcolor="#666666"><span class="style2 style3">Grand Total</span></td>
                <td colspan="3" bgcolor="#666666"><span class="style2 style3">Action </span></td>
            </tr>

            <?php
            $totalSum = 0;
            $discountSum = 0;
            $grandTotalSum = 0;
            ?>

            <?php do { ?>
                <tr <?php echo shouldHighlightRow($row_Recordset1['date'], $selectedMonth) ? 'class="highlighted-row"' : ''; ?>>

                    <td><span class="style3"><?php echo $row_Recordset1['fname']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['lname']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['gender']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['age']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['status']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['phone']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['dob']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['address']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['procedure']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['visit']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['date']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['total']; ?></span></td>
                    <td><span class="style3"><?php echo $row_Recordset1['discount']; ?></span></td>
                    <td><span class="style3"><b style="color:green;"><?php echo $row_Recordset1['finalAmount']; ?></b></span></td>
                    <td style="width: 33px;"><a title="delete" href="Delete.php?id=<?php echo $row_Recordset1['id']; ?>"><i class="fas fa-trash"></i></a></td>
                    <td style="width: 33px;"><a title="print" target="_blank" href="print.php?id=<?php echo $row_Recordset1['id']; ?>"><i class="fas fa-print"></i></a></td>
                    <td style="width: 33px;"><a title="update" href="update.php?id=<?php echo $row_Recordset1['id']; ?>"><i class="fas fa-edit"></i></a></td>
                </tr>

                <?php
                $totalSum += $row_Recordset1['total'];
                $discountSum += $row_Recordset1['discount'];
                $grandTotalSum += $row_Recordset1['finalAmount'];
                ?>



            <?php } while ($row_Recordset1 = $result_Recordset1->fetch_assoc());
            ?>

            <tr style="font-weight: bold; color:green; text-align:center;">
                <td colspan="2" style="text-align:center;">Total Sums:</td>
                <td colspan="9" style="text-align: right;"></td>
                <td style="text-align: center;"><?php echo $totalSum; ?></td>
                <td style="text-align: center;"><?php echo $discountSum; ?></td>
                <td style="text-align: center;"><?php echo $grandTotalSum; ?></td>
                <td colspan="3"></td> <!-- Empty columns for spacing -->
            </tr>
        </table>

    </div>

    <!-- Total number of records -->
    <p style="font-size: 19px; color: #2980b9; text-align: end; padding: 20px; text-decoration: underline">Total Records: <b style="background-color: #2980b9; color: white; padding: 2px 5px; border-radius: 3px;"> <?php echo $totalRows_TotalRecords; ?></b></p>


<?php } else {
    echo "No records found.";
} ?>


<!-- js for records filtering monthly vise and status -->
<script>
    function filterRecords() {
        var selectedStatus = document.getElementById("statusFilter").value;
        var selectedMonth = document.getElementById("monthFilter").value;

        var queryParams = [];

        if (selectedStatus !== "") {
            queryParams.push("status=" + encodeURIComponent(selectedStatus));
        }

        if (selectedMonth !== "") {
            queryParams.push("month=" + selectedMonth);
        }

        // Redirect to records.php with the selected filters as query parameters
        if (queryParams.length > 0) {
            window.location.href = "records.php?" + queryParams.join("&");
        } else {
            // If no filters are selected, redirect without query parameters
            window.location.href = "records.php";
        }
    }
</script>