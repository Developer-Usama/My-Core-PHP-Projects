<?php
require_once('Connections/conn.php');
include 'Header.php';

// Start a session or resume the existing session
session_start();

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
    $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['user'])) {
    $loginUsername = $_POST['user'];
    $password = $_POST['pass'];

    $conn = new mysqli($hostname_conn, $username_conn, $password_conn, $database_conn);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $LoginRS__query = sprintf(
        "SELECT user, pass FROM login WHERE user='%s' AND pass='%s'",
        $conn->real_escape_string($loginUsername),
        $conn->real_escape_string($password)
    );

    $LoginRS = $conn->query($LoginRS__query);
    if (!$LoginRS) {
        die("Query failed: " . $conn->error);
    }

    $loginFoundUser = $LoginRS->num_rows;
    if ($loginFoundUser) {
        // User is logged in, store user-specific data in session variables
        $_SESSION['MM_Username'] = $loginUsername;
        $_SESSION['MM_UserGroup'] = $loginStrGroup;

        if (isset($_SESSION['PrevUrl']) && $_SESSION['PrevUrl'] != "") {
            $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];
        } else {
            $MM_redirectLoginSuccess = "entry.php"; // Change this to your desired success page
        }

        header("Location: " . $MM_redirectLoginSuccess);
        exit();
    } else {
        // Redirect to a failure page
        $MM_redirectLoginFailed = "fail.php"; // Change this to your desired failure page
        header("Location: " . $MM_redirectLoginFailed);
        exit();
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <!-- This file has been downloaded from Bootsnipp.com. Enjoy! -->
    <title>INU Dental Clinic Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        /*    --------------------------------------------------
	:: Login Section
	-------------------------------------------------- */
        #login {
            padding-top: 50px
        }

        #login .form-wrap {
            width: 30%;
            margin: 0 auto;
        }

        #login h1 {
            color: #1fa67b;
            font-size: 18px;
            text-align: center;
            font-weight: bold;
            padding-bottom: 20px;
        }

        #login .form-group {
            margin-bottom: 25px;
        }

        #login .checkbox {
            margin-bottom: 20px;
            position: relative;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -o-user-select: none;
            user-select: none;
        }

        #login .checkbox.show:before {
            content: '\e013';
            color: #1fa67b;
            font-size: 17px;
            margin: 1px 0 0 3px;
            position: absolute;
            pointer-events: none;
            font-family: 'Glyphicons Halflings';
        }

        #login .checkbox .character-checkbox {
            width: 25px;
            height: 25px;
            cursor: pointer;
            border-radius: 3px;
            border: 1px solid #ccc;
            vertical-align: middle;
            display: inline-block;
        }

        #login .checkbox .label {
            color: #6d6d6d;
            font-size: 13px;
            font-weight: normal;
        }

        #login .btn.btn-custom {
            font-size: 14px;
            margin-bottom: 20px;
        }

        #login .forget {
            font-size: 13px;
            text-align: center;
            display: block;
        }

        /*    --------------------------------------------------
	:: Inputs & Buttons
	-------------------------------------------------- */
        .form-control {
            color: #212121;
        }

        .btn-custom {
            color: #fff;
            background-color: #1fa67b;
        }

        .btn-custom:hover,
        .btn-custom:focus {
            color: #fff;
        }

        /*    --------------------------------------------------
    :: Footer
	-------------------------------------------------- */
        #footer {
            color: #6d6d6d;
            font-size: 12px;
            text-align: center;
        }

        #footer p {
            margin-bottom: 0;
        }

        #footer a {
            color: inherit;
        }
    </style>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        function validateID() {
            var address = document.getElementById('email');

            if (address.value == "") {
                alert("ID must be filled out");
                document.form1.email.focus();

                return false;
            } else if (document.getElementById('email').value.length > 5) {

                alert("Your ID cannot be more than 5 characters");

                document.form1.email.focus();
                return false;
            } else if (/[^a-zA-Z0-9\-\/]/.test(address)) {

                alert('contain alphanumeric characters, hyphens(-) and back slashs(\)');

                document.form1.email.focus();
                return false;
            }

        }


        function validatePassword() {
            var address = document.getElementById('key');

            if (address.value == "") {
                alert("Password must be filled out");


                document.form1.key.focus();
                return false;
            } else if (document.getElementById('key').value.length > 5) {
                alert("Your ID cannot be more than 5 characters");
                document.form1.key.focus();
                return false;
            } else if (/[^a-zA-Z0-9\-\/]/.test(address)) {
                alert('contain alphanumeric characters, hyphens(-) and back slashs(\)');
                $('#bt').css('display', 'none');
                ocument.form1.key.focus();
                return false;
            }

        }
    </script>

    </script>
</head>

<body>
    <section id="login">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                            <div align="center"><img src="inu-logo.png" width="88" height="88"> </div>
                        </div>
                        <div class="col-md-12">
                            <h3 align="center"><strong>IQRA National University</strong></h3>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12">

                    <div class="form-wrap" style=" box-shadow: black inset 0px 1px 2px; background-color: #e3f9fa; padding:1.5% 4%; margin:1% auto; width:50%; border-radius:1rem;">
                        <h1>INU Dental Clinic Management System </h1>
                        <form METHOD="POST" action="<?php echo $loginFormAction; ?>" name="login-form" id="login-form" role="form" autocomplete="off">
                            <div class="form-group">
                                <label for="email" class="sr-only">Email</label>
                                <input name="user" type="text" class="form-control" id="user" placeholder="Employee ID" required>
                            </div>
                            <div class="form-group">
                                <label for="key" class="sr-only">Password</label>
                                <input name="pass" type="password" class="form-control" id="pass" placeholder="Password" required>
                            </div>

                            <div id="bt"><input type="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Log in"></div>
                        </form>
                        <a href="#" class="forget" data-toggle="modal" data-target=".forget-modal">Forgot your password?</a>
                        <hr>
                    </div>
                </div> <!-- /.col-xs-12 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
    </section>

    <div class="modal fade forget-modal" tabindex="-1" role="dialog" aria-labelledby="myForgetModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true"></span>
                        <span class="sr-only">Close</span>
                    </button>
                    <h4 class="modal-title">Recovery password</h4>
                </div>
                <div class="modal-body">
                    <p>Type your email account</p>
                    <input type="email" name="recovery-email" id="recovery-email" class="form-control" autocomplete="off">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-custom">Recovery</button>
                </div>
            </div> <!-- /.modal-content -->
        </div> <!-- /.modal-dialog -->
    </div> <!-- /.modal -->

    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <p>Copyright &copy; - 2023</p>
                    <p>Powered by <strong>IQRA National University </strong></p>
                </div>
            </div>
        </div>
    </footer>
    <script type="text/javascript">
        function showPassword() {

            var key_attr = $('#key').attr('type');

            if (key_attr != 'text') {

                $('.checkbox').addClass('show');
                $('#key').attr('type', 'text');

            } else {

                $('.checkbox').removeClass('show');
                $('#key').attr('type', 'password');

            }

        }
    </script>
</body>

</html