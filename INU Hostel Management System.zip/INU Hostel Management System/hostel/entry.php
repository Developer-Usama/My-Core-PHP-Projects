<?php
require_once('Connections/conn.php');

// Initialize the session
if (!isset($_SESSION)) {
    session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF'] . "?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")) {
    $logoutAction .= "&" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) && ($_GET['doLogout'] == "true")) {
    // To fully log out a visitor, clear the session variables
    $_SESSION['MM_Username'] = NULL;
    $_SESSION['MM_UserGroup'] = NULL;
    $_SESSION['PrevUrl'] = NULL;
    unset($_SESSION['MM_Username']);
    unset($_SESSION['MM_UserGroup']);
    unset($_SESSION['PrevUrl']);

    $logoutGoTo = "index.php";
    if ($logoutGoTo) {
        header("Location: $logoutGoTo");
        exit;
    }
}

// Function to sanitize values (now using modern escaping)
function GetSQLValueString($conn, $theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")
{
    switch ($theType) {
        case "text":
            return ($theValue != "") ? "'" . $conn->real_escape_string($theValue) . "'" : "NULL";
        case "int":
            return ($theValue != "") ? intval($theValue) : "NULL";
        case "double":
            return ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
        case "date":
            return ($theValue != "") ? "'" . $conn->real_escape_string($theValue) . "'" : "NULL";
        case "defined":
            return ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
    }
    return "NULL";
}

$editFormAction = $_SERVER['PHP_SELF'];

if (isset($_SERVER['QUERY_STRING'])) {
    $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (isset($_POST["MM_insert"]) && $_POST["MM_insert"] == "form1") {
    // Use prepared statements instead of sprintf
    $insertSQL = "INSERT INTO fee (sname, fname, degree, sid, status, month, year, fee, paid, feemonth, rfid) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($insertSQL)) {
        $stmt->bind_param(
            "sssissiiisi",
            $_POST['sname'],
            $_POST['fname'],
            $_POST['degree'],
            $_POST['sid'],
            $_POST['status'],
            $_POST['month'],
            $_POST['year'],
            $_POST['fee'],
            $_POST['paid'],
            $_POST['feemonth'],
            $_POST['rfid']
        );

        if ($stmt->execute()) {
            header('Location: all.php');
            exit();
        } else {
            die("Database error: " . $conn->error);
        }

        $stmt->close();
    } else {
        die("Preparation failed: " . $conn->error);
    }
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hostel Fee Registration</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">


  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
  <script>
    $(function() {
      $("#datepicker").datepicker();
    });
  </script>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title>INU Dental Clinic</title>


  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }


    textarea {
      width: 100%;
      height: 80px;
      padding: 5px 15px;
      box-sizing: border-box;
      border: 2px solid #ccc;
      border-radius: .5rem;
      background-color: #ffffff;
      font-size: 13px;
      resize: none;

    }

    .style2 {
      color: #FFFFFF
    }



    input[type=text],
    select {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    input[type=submit] {
      width: 50%;
      background-color: #4CAF50;
      color: white;
      padding: 14px 20px;
      margin: 8px auto;
      display: block;
      font-weight: bold;
      align-items: center;
      justify-content: center;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    input[type=submit]:hover {
      background-color: #45a049;
    }


    .style3 {
      font-family: Arial, Helvetica, sans-serif
    }


    body {
      font-family: Arial, sans-serif;
      background-image: url('background.png');
    }

    form {
      background-color: #e3f9fa;
      box-shadow: black inset 0px 1px 2px;
      border-radius: 1rem;
      padding: 1rem;
      max-width: 70%;
      margin: 1rem auto;
    }

    table {
      width: 100%;
    }

    td {
      padding: 0;
      /* margin: 0; */
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #ddd;
      border-radius: 0.5rem;
    }

    .radio-group {
      display: flex;
      gap: 1rem;
      font-size: 12px;
    }

    .checkbox-group {
      display: flex;
      flex-wrap: wrap;
      font-size: 12px;
      width: 100%;
      justify-content: space-between;
    }

    .checkbox-row {
      width: calc(33.33% - 1rem);
      margin-bottom: 0.5rem;
      box-sizing: border-box;
    }

    #total,
    #finalAmount {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #ddd;
      border-radius: 0.5rem;
      font-weight: bold;
    }


    /* Responsive Design */
    @media (max-width: 768px) {
      form {
        max-width: 100%;
      }

      .style1 {
        font-size: 20px;
      }

      .checkbox-row {
        width: calc(50% - 1rem);
      }
    }

    @media (max-width: 480px) {
      .checkbox-row {
        width: 100%;
      }

    }
  </style>


  <style type="text/css">
    .style1 {
      margin-top: 0px;
      padding-top: .5rem;
      font-size: 32px
    }
  </style>

  <script type="text/JavaScript">
    <!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
  </script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
  <script>
    $(function() {
      $("#datepicker").datepicker();
    });
  </script>
</head>
<style>
  input[type=text],
  select {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  input[type=submit] {
    width: 100%;
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  input[type=submit]:hover {
    background-color: #45a049;
  }


  .style3 {
    font-family: Arial, Helvetica, sans-serif
  }

  .button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #007BFF;
    margin-bottom: 5rem;
    /* Blue color */
    color: #fff;
    /* Text color */
    text-decoration: none;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .button:hover {
    background-color: #0056b3;
    /* Darker blue color on hover */
  }
</style>



<body>
  <div align="center">
    <p class="style1"><img src="logo.png" width="120" height="120" /></p>
    <p class="style1">IQRA National University Peshawar<br /> </p>
    <p class="head" style="color:#45a049; font-size:30px; margin-top:1rem;"> Hostel Management System<br>
      Fee Registration Form </p>
  </div>

  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <table width="50%" align="center">
      <tr valign="baseline">
        <td><span class="style3">Student Name:</span> </td>
        <td><span class="style3">Student Father Name: </span></td>
      </tr>
      <tr valign="baseline">
        <td><input type="text" name="sname" value="" placeholder="Student Name" size="32" /></td>
        <td><input type="text" name="fname" value="" placeholder="Student Father Name" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Student Degree </span></td>
        <td><span class="style3">Student ID </span></td>
      </tr>
      <tr valign="baseline">
        <td><select name="degree" id="degree">
            <option value="Select Degree" <?php if (!(strcmp("Select Degree", ""))) {
                                            echo "SELECTED";
                                          } ?>>Select Degree</option>
            <option value="BBA" <?php if (!(strcmp("BBA", ""))) {
                                  echo "SELECTED";
                                } ?>>BBA</option>
            <option value="BBA 2 YEAR" <?php if ((strcmp("BBA 2 YEAR", ""))) {
                                          echo "SELECTED";
                                        } ?>>BBA 2 YEAR</option>
            <option value="MBA" <?php if ((strcmp("MBA", ""))) {
                                  echo "SELECTED";
                                } ?>>MBA</option>
            <option value="BE(C)" <?php if ((strcmp("BE(C)", ""))) {
                                    echo "SELECTED";
                                  } ?>>BE(C)</option>
            <option value="BE(E)" <?php if ((strcmp("BE(E)", ""))) {
                                    echo "SELECTED";
                                  } ?>>BE(E)</option>
            <option value="BFD" <?php if ((strcmp("BFD", ""))) {
                                  echo "SELECTED";
                                } ?>>BFD</option>
            <option value="BID" <?php if ((strcmp("BID", ""))) {
                                  echo "SELECTED";
                                } ?>>BID</option>
            <option value="BS(CS)" <?php if ((strcmp("BS(CS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(CS)</option>
            <option value="BS(HND)" <?php if ((strcmp("BS(HND)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(HND)</option>
            <option value="BS(SURG)" <?php if ((strcmp("BS(SURG)", ""))) {
                                        echo "SELECTED";
                                      } ?>>BS(SURG)</option>
            <option value="BS(ANS)" <?php if ((strcmp("BS(ANS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(ANS)</option>
            <option value="BS(CARD)" <?php if ((strcmp("BS(CARD)", ""))) {
                                        echo "SELECTED";
                                      } ?>>BS(CARD)</option>
            <option value="BS(DT)" <?php if ((strcmp("BS(DT)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(DT)</option>
            <option value="BS(ENG)" <?php if ((strcmp("BS(ENG)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(ENG)</option>
            <option value="BS(MLT)" <?php if ((strcmp("BS(MLT)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(MLT)</option>
            <option value="BS(MIC)" <?php if ((strcmp("BS(MIC)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(MIC)</option>
            <option value="BS(MMC)" <?php if ((strcmp("BS(MMC)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(MMC)</option>
            <option value="BS(PSY)" <?php if ((strcmp("BS(PSY)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(PSY)</option>
            <option value="BS(RAD)" <?php if ((strcmp("BS(RAD)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(RAD)</option>
            <option value="BS(SE)" <?php if ((strcmp("BS(SE)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(SE)</option>
            <option value="BS(SS)" <?php if ((strcmp("BS(SS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>BS(SS)</option>
            <option value="BTD" <?php if ((strcmp("BTD", ""))) {
                                  echo "SELECTED";
                                } ?>>BTD</option>
            <option value="B-TECH(C)" <?php if ((strcmp("B-TECH(C)", ""))) {
                                        echo "SELECTED";
                                      } ?>>B-TECH(C)</option>
            <option value="B-TECH(E)" <?php if ((strcmp("B-TECH(E)", ""))) {
                                        echo "SELECTED";
                                      } ?>>B-TECH(E)</option>
            <option value="DPT" <?php if ((strcmp("DPT", ""))) {
                                  echo "SELECTED";
                                } ?>>DPT</option>
            <option value="MBA(BB)" <?php if ((strcmp("MBA(BB)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MBA(BB)</option>
            <option value="MBA(NB)" <?php if ((strcmp("MBA(NB)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MBA(NB)</option>
            <option value="MS(CE)" <?php if ((strcmp("MS(CE)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(CE)</option>
            <option value="MS(CS)" <?php if ((strcmp("MS(CS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(CS)</option>
            <option value="MS(MS)" <?php if ((strcmp("MS(MS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(MS)</option>
            <option value="MS(TE)" <?php if ((strcmp("MS(TE)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(TE)</option>
            <option value="MBA(BB)" <?php if ((strcmp("MBA(BB)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MBA(BB)</option>
            <option value="MBA(NB)" <?php if ((strcmp("MBA(NB)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MBA(NB)</option>
            <option value="MS(CE)" <?php if ((strcmp("MS(CE)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(CE)</option>
            <option value="MS(CS)" <?php if ((strcmp("MS(CS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(CS)</option>
            <option value="MS(MS)" <?php if ((strcmp("MS(MS)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(MS)</option>
            <option value="MS(TE)" <?php if ((strcmp("MS(TE)", ""))) {
                                      echo "SELECTED";
                                    } ?>>MS(TE)</option>
            <option value="MS(EL.E)" <?php if ((strcmp("MS(EL.E))", ""))) {
                                        echo "SELECTED";
                                      } ?>>MS(EL.E)</option>
            <option value="P.HD(C.S)" <?php if ((strcmp("P.HD(C.S)", ""))) {
                                        echo "SELECTED";
                                      } ?>>P.HD(C.S)</option>
            <option value="P.HD(EL.E)" <?php if ((strcmp("P.HD(EL.E)", ""))) {
                                          echo "SELECTED";
                                        } ?>>P.HD(EL.E)</option>
            <option value="P.HD(MS)" <?php if ((strcmp("P.HD(MS)", ""))) {
                                        echo "SELECTED";
                                      } ?>>P.HD(MS)</option>
          </select></td>
        <td><input type="text" name="sid" value="" placeholder="Student ID" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Student Status </span></td>
        <td><span class="style3">Fee For month </span></td>
      </tr>
      <tr valign="baseline">
        <td><select name="status">
            <option value="Peshawar Student" <?php if (!(strcmp("Peshawar Student", ""))) {
                                                echo "SELECTED";
                                              } ?>>Peshawar Student</option>
            <option value="Swat Student" <?php if (!(strcmp("Swat Student", ""))) {
                                            echo "SELECTED";
                                          } ?>>Swat Student</option>
          </select></td>
        <td> <select name="month" id="month">
            <option value="Select month">Select month</option>
            <option value="January">January</option>
            <option value="February">February</option>
            <option value="March">March</option>
            <option value="April">April</option>
            <option value="May">May</option>
            <option value="June">June</option>
            <option value="July">July</option>
            <option value="August">August</option>
            <option value="September">September</option>
            <option value="October">October</option>
            <option value="November">November</option>
            <option value="December">December</option>
          </select>



        </td>




      </tr>

      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Fee For Year </span></td>
        <td><span class="style3">Hostel Fee </span></td>

      </tr>
      <tr valign="baseline">
        <td> <select name="year" id="year">
            <option value="Select year">Select year</option>
            <?php
            $currentYear = date("Y");
            for ($i = $currentYear; $i >= ($currentYear - 10); $i--) {
              echo "<option value='$i'>$i</option>";
            }
            ?>
          </select></td>

        <td><input type="text" name="fee" value="0" placeholder="Hostel Fee" size="32" /></td>
      </tr>



      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td><span class="style3">Paid Fee </span></td>
        <td><span class="style3">Fee Submission Date </span></td>
      </tr>
      <tr valign="baseline">
        <td><input type="text" name="paid" value="0" placeholder="Paid Fee" size="32" /></td>

        <td><input type="text" id="datepicker" name="feemonth" value="" placeholder="Fee Submission Date" size="32" /></td>
      </tr>
      <tr valign="baseline">
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr valign="baseline">
        <td colspan="2"><input name="submit" type="submit" onclick="MM_validateForm('sname','','R','fname','','R','degree','','R','sid','','RisNum','semester','','R','fee','','RisNum','feemonth','','R','rfid','','RisNum');return document.MM_returnValue" value="Submit Record" /></td>
      </tr>
    </table>
    <p>
      <input type="hidden" name="MM_insert" value="form1">
    </p>
  </form>
  <p align="center">
    <a class="button" href="all.php">All Record</a>
    <a class="button" style="background-color: red;" href="<?php echo $logoutAction ?>">Log out</a>
  </p>



</body>

</html>