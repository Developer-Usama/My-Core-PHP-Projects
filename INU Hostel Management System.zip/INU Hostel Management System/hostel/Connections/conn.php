<?php
error_reporting(E_ALL & ~E_NOTICE);

$hostname_conn = "localhost";
$database_conn = "hostel";
$username_conn = "root";
$password_conn = "";

// Create connection
$conn = new mysqli($hostname_conn, $username_conn, $password_conn, $database_conn);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// echo "Connected successfully";
?>
