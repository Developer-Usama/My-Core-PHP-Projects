Records -
 <span id="<?php echo $dtable->listName;?>_nav_from"><?php echo $dtable->getStats('from'); ?></span>
 <?php echo ("to"); ?>
 <span id="<?php echo $dtable->listName;?>_nav_to"><?php echo $dtable->getStats('to'); ?></span>
 <?php echo ("of"); ?>
  <span id="<?php echo $dtable->listName;?>_nav_total"><?php echo $dtable->getStats('of'); ?></span>
