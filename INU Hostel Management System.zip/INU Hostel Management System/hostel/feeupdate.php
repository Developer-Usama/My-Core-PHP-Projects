<?php require_once('Connections/conn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf(
    "UPDATE fee SET sname=%s, fname=%s, degree=%s, sid=%s, status=%s, month=%s, year=%s, fee=%s, feemonth=%s, rfid=%s, sdate=%s WHERE id=%s",
    GetSQLValueString($_POST['sname'], "text"),
    GetSQLValueString($_POST['fname'], "text"),
    GetSQLValueString($_POST['degree'], "text"),
    GetSQLValueString($_POST['sid'], "int"),
    GetSQLValueString($_POST['status'], "text"),
    GetSQLValueString($_POST['month'], "text"),
    GetSQLValueString($_POST['year'], "int"),
    GetSQLValueString($_POST['fee'], "int"),
    GetSQLValueString($_POST['feemonth'], "text"),
    GetSQLValueString($_POST['rfid'], "int"),
    GetSQLValueString($_POST['sdate'], "date"),
    GetSQLValueString($_POST['id'], "int")
  );

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($updateSQL, $conn) or die(mysql_error());

  $updateGoTo = "all.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_Recordset1 = "-1";
if (isset($_GET['id'])) {
  $colname_Recordset1 = (get_magic_quotes_gpc()) ? $_GET['id'] : addslashes($_GET['id']);
}
mysql_select_db($database_conn, $conn);
$query_Recordset1 = sprintf("SELECT * FROM fee WHERE id = %s", $colname_Recordset1);
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <title></title>
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
  <script>
    $(function() {
      $("#datepicker").datepicker();
    });
  </script>
  <style type="text/css">
    <!--
    .style1 {
      font-size: 24px
    }

    .style2 {
      font-family: Arial, Helvetica, sans-serif
    }
    -->
  </style>
</head>

<body>
  <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
    <p align="center"><img src="logo.png" width="120" height="120" /></p>
    <div align="center">
      <p class="style1">Iqra National University Peshawar <br />
        Update Record </p>
    </div>
    <table align="center">
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Student Name: </span></div>
        </td>
        <td><input type="text" name="sname" value="<?php echo $row_Recordset1['sname']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Father Name :</span></div>
        </td>
        <td><input type="text" name="fname" value="<?php echo $row_Recordset1['fname']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Degree:</span></div>
        </td>
        <td><input type="text" name="degree" value="<?php echo $row_Recordset1['degree']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Student ID :</span></div>
        </td>
        <td><input type="text" name="sid" value="<?php echo $row_Recordset1['sid']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Status:</span></div>
        </td>
        <td><input type="text" name="status" value="<?php echo $row_Recordset1['status']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">month:</span></div>
        </td>
        <td><input type="text" name="month" value="<?php echo $row_Recordset1['month']; ?>" size="32"></td>
      </tr>

      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Fee:</span></div>
        </td>
        <td><input type="text" name="fee" value="<?php echo $row_Recordset1['fee']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">Paid Fee Month :</span></div>
        </td>
        <td><input type="text" id="datepicker" name="feemonth" value="<?php echo $row_Recordset1['feemonth']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">
          <div align="left"><span class="style2">RFID:</span></div>
        </td>
        <td><input type="text" name="rfid" value="<?php echo $row_Recordset1['rfid']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">Fee Submition Date :</td>
        <td><input type="text" name="sdate" value="<?php echo $row_Recordset1['sdate']; ?>" size="32"></td>
      </tr>
      <tr valign="baseline">
        <td nowrap align="right">&nbsp;</td>
        <td><input type="submit" value="Update Recard"></td>
      </tr>
    </table>
    <input type="hidden" name="MM_update" value="form1">
    <input type="hidden" name="id" value="<?php echo $row_Recordset1['id']; ?>">
  </form>
  <p>&nbsp;</p>
  <div align="center"></div>
</body>

</html>
<?php
mysql_free_result($Recordset1);
?>