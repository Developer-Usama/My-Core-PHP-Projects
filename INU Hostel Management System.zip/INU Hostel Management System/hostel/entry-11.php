<?php require_once('Connections/conn.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO registration (fname, lname, gender, age, status, phone, dob, address, `procedure`, visit) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['fname'], "text"),
                       GetSQLValueString($_POST['lname'], "text"),
                       GetSQLValueString($_POST['gender'], "text"),
                       GetSQLValueString($_POST['age'], "int"),
                       GetSQLValueString($_POST['status'], "text"),
                       GetSQLValueString($_POST['phone'], "int"),
                       GetSQLValueString($_POST['dob'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['procedure'], "text"),
                       GetSQLValueString($_POST['visit'], "text"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($insertSQL, $conn) or die(mysql_error());
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE fee SET sname=%s, fname=%s, degree=%s, sid=%s, status=%s, semester=%s, fee=%s, feemonth=%s, rfid=%s WHERE id=%s",
                       GetSQLValueString($_POST['sname'], "text"),
                       GetSQLValueString($_POST['fname'], "text"),
                       GetSQLValueString($_POST['degree'], "text"),
                       GetSQLValueString($_POST['sid'], "int"),
                       GetSQLValueString($_POST['status'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['fee'], "int"),
                       GetSQLValueString($_POST['feemonth'], "text"),
                       GetSQLValueString($_POST['rfid'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($updateSQL, $conn) or die(mysql_error());
}

mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM registration ORDER BY `date` ASC";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>INU Dental Clinic</title>
<style type="text/css">
<!--
.style1 {font-size: 24px}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>


<style> 
textarea {
  width: 100%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #ffffff;
  font-size: 16px;
  resize: none;
}
.style2 {color: #FFFFFF}
</style>



</head>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}


.style3 {font-family: Arial, Helvetica, sans-serif}
</style>
<body>
<div align="center">
  <p class="style1"><img src="logo.png" width="120" height="120" /></p>
  <p class="style1">Iqra National University Dental Clinic<br />
    Patient Registrtion Form  </p>
  <p class="style1">&nbsp;</p>
  <p class="style1">&nbsp;</p>

  <p>&nbsp;</p>
</div>

<form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
  <p>&nbsp;</p>
  <table width="50%" align="center">
    <tr valign="baseline">
      <td><span class="style3">Student Name:</span> </td>
      <td><span class="style3">Stdent Father Name: </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="sname" value="" placeholder="Student Name" size="32" /></td>
      <td><input type="text" name="fname" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Student Degree </span></td>
      <td><span class="style3">Student ID </span></td>
    </tr>
    <tr valign="baseline">
      <td><select name="degree">
        <option value="BCS" <?php if (!(strcmp("BCS", ""))) {echo "SELECTED";} ?>>BCS</option>
        <option value="MCS" <?php if (!(strcmp("MCS", ""))) {echo "SELECTED";} ?>>MCS</option>
      </select></td>
      <td><input type="text" name="sid" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Student Status </span></td>
      <td><span class="style3">Student Semester </span></td>
    </tr>
    <tr valign="baseline">
      <td><select name="status">
        <option value="WWB" <?php if (!(strcmp("WWB", $row_Recordset1['status']))) {echo "SELECTED";} ?>>WWB</option>
        <option value="Regular" <?php if (!(strcmp("Regular", $row_Recordset1['status']))) {echo "SELECTED";} ?>>Regular</option>
      </select></td>
      <td><select name="semester">
        <option value="Ist" <?php if (!(strcmp("Ist", ""))) {echo "SELECTED";} ?>>Ist </option>
        <option value="Second" <?php if (!(strcmp("Second", ""))) {echo "SELECTED";} ?>>Second</option>
        <option value="" >item1</option>
      </select></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Hostel Fee  </span></td>
      <td><span class="style3">Fee Month </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="fee" value="" size="32" /></td>
      <td><input type="text" name="feemonth" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><span class="style3">Student RFID </span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><input type="text" name="rfid" value="" size="32" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><input type="submit" onclick="MM_validateForm('fname','','R','lname','','R','age','','RisNum','phone','','RisNum','dob','','R');return document.MM_returnValue" value="Submit Record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p align="center">&nbsp;<a href="<?php echo $logoutAction ?>">Log out</a></p>
<p>&nbsp;</p>

<?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table border="1" align="center" cellpadding="2">
    <tr>
      <td bgcolor="#666666"><span class="style2 style3">S.No</span></td>
      <td bgcolor="#666666"><span class="style2 style3">First Name </span></td>
      <td bgcolor="#666666"><span class="style2 style3">Last Name </span></td>
      <td bgcolor="#666666"><span class="style2 style3">Sex</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Age</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Status</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Phone</span></td>
      <td bgcolor="#666666"><span class="style2 style3">DOB</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Address</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Procedure</span></td>
      <td bgcolor="#666666"><span class="style2 style3">Visit</span></td>
      <td colspan="4" bgcolor="#666666"><span class="style2 style3">Entry Date </span></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><span class="style3"><?php echo $row_Recordset1['id']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['fname']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['lname']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['gender']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['age']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['status']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['phone']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['dob']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['address']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['procedure']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['visit']; ?></span></td>
        <td><span class="style3"><?php echo $row_Recordset1['date']; ?></span></td>
        <td><a href="Delete.php?id=<?php echo $row_Recordset1['id']; ?>"><img src="cross-23-16.png" width="16" height="16" border="0" /></a></td>
        <td><a href="print.php?id=<?php echo $row_Recordset1['id']; ?>"><img src="p.png" width="12" height="12" border="0" /></a></td>
        <td><a href="update.php?id=<?php echo $row_Recordset1['id']; ?>"><img src="to-update-2-16.png" width="16" height="16" border="0" /></a></td>
      </tr>
      <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
  </table>
  <br />
  <br />
<?php } // Show if recordset not empty ?></body>

</html>
<?php
mysql_free_result($Recordset1);
?>
