<?php
require_once('Connections/conn.php');
include "Header.php";

mysql_select_db($database_conn, $conn);

// Initialize search values for each search type
$search_id = "";
$search_month = "";
$search_year = "";


$totalFee = 0; // Initialize the total fee variable



// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["search_id"])) {
        $search_id = $_POST["search_id"];
    }
    if (isset($_POST["search_month"])) {
        $search_month = $_POST["search_month"];
    }
    if (isset($_POST["search_year"])) {
        $search_year = $_POST["search_year"];
    }
}

// Query the database based on the selected search type
$query = "SELECT * FROM fee WHERE 1";

if (!empty($search_id)) {
    $query .= " AND sid = '$search_id'";
}

if (!empty($search_month)) {
    $query .= " AND month = '$search_month'";
}

if (!empty($search_year)) {
    $query .= " AND year = '$search_year'";
}

$query .= " ORDER BY id DESC"; // Sort by 'id' column in descending order

$result = mysql_query($query, $conn) or die(mysql_error());


?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Hostel Fee Search</title>


    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        .top-section {
            background-color: #007BFF;
            color: white;
            padding: 10px 0;
            text-align: right;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 20px;
        }

        .button {
            display: inline-block;
            padding: 4px 8px;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #0056b3;
            color: white;
        }

        h1 {
            margin: 5px 0;
            font-size: 14px;
            padding: 1rem;
        }


        form {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 20px;
        }

        .form-group {
            flex: 1;
            margin: 10px;
        }

        label {
            font-weight: bold;
            display: block;
            font-size: 13px;
        }

        select,
        input[type="text"] {
            width: 100%;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 1rem;
        }

        input[type="submit"] {
            padding: 5px 10px;
            margin-top: 1rem;
            background-color: #007BFF;
            color: white;
            margin-left: 3rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 95%;
            display: block;
            margin: auto;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #007BFF;
            color: white;
        }
    </style>

</head>

<body>

    <div class="top-section" style="background-color: green; height:3rem; color:white;  padding-right:1rem;">

        <p align="right">
            <a class="button" href="entry.php">New Record</a>
            <a class="button" style="background-color: red;" href="logout.php">Log out</a>
        </p>

    </div>

    <h1 style="text-align: center; color:green">Hostel Fee Search</h1>
    <form method="post" action="">
        <div>
            <label for="search_id">Search by ID:</label>
            <input type="text" placeholder="Search by Student ID" id="search_id" name="search_id" value="<?php echo $search_id; ?>">
        </div>
        <div>
            <label for="search_month">Search by Month:</label>
            <select id="search_month" name="search_month">
                <option value="" <?php if (empty($search_month)) echo 'selected'; ?>>Select month</option>
                <option value="January" <?php if ($search_month === 'January') echo 'selected'; ?>>January</option>
                <option value="February" <?php if ($search_month === 'February') echo 'selected'; ?>>February</option>
                <option value="March" <?php if ($search_month === 'March') echo 'selected'; ?>>March</option>
                <option value="April" <?php if ($search_month === 'April') echo 'selected'; ?>>April</option>
                <option value="May" <?php if ($search_month === 'May') echo 'selected'; ?>>May</option>
                <option value="June" <?php if ($search_month === 'June') echo 'selected'; ?>>June</option>
                <option value="July" <?php if ($search_month === 'July') echo 'selected'; ?>>July</option>
                <option value="August" <?php if ($search_month === 'August') echo 'selected'; ?>>August</option>
                <option value="September" <?php if ($search_month === 'September') echo 'selected'; ?>>September</option>
                <option value="October" <?php if ($search_month === 'October') echo 'selected'; ?>>October</option>
                <option value="November" <?php if ($search_month === 'November') echo 'selected'; ?>>November</option>
                <option value="December" <?php if ($search_month === 'December') echo 'selected'; ?>>December</option>
            </select>
        </div>
        <div>
            <label for="search_year">Search by Year:</label>
            <select id="search_year" name="search_year">
                <option value="" <?php if (empty($search_year)) echo 'selected'; ?>>Select year</option>
                <?php
                // Generate the year options dynamically, adjust the range as needed
                $currentYear = date("Y");
                for ($year = $currentYear; $year >= 2000; $year--) {
                    echo "<option value='$year' ";
                    if ($search_year == $year) {
                        echo 'selected';
                    }
                    echo ">$year</option>";
                }
                ?>
            </select>
        </div>
        <input type="submit" value="Search">
        <button style="border: none; margin-top:1rem; margin-left:1rem;">
            <a style="padding:4px 8px; border-radius:5px; color:white; background-color:green; border:none; outline:none;" class="button" href="all.php">Back to Records</a>
        </button>

    </form>

    <hr>

    <?php if (mysql_num_rows($result) > 0) { ?>
        <h3 style="padding: 0rem 0rem 0rem 1rem;  text-decoration:underline; color:#0056b3;">All Records</h3>
        <div style="width: auto; display:block; margin:auto; border:none;">

            <table border="1" style="display: block; margin: 0 auto 1rem auto; border:none;">
                <tr>
                    <th>Student Name</th>
                    <th>Father Name</th>
                    <th>Degree</th>
                    <th>Student ID</th>
                    <th>Student Status</th>
                    <th>Month</th>
                    <th>Year</th>
                    <th>Fee</th>
                    <th>Paid Fee Month</th>
                    <th colspan="4">Action</th>
                </tr>
                <?php while ($row = mysql_fetch_assoc($result)) {

                    $totalFee += $row['fee'];

                ?>
                    <tr>
                        <td><?php echo $row['sname']; ?></td>
                        <td><?php echo $row['fname']; ?></td>
                        <td><?php echo $row['degree']; ?></td>
                        <td><?php echo $row['sid']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['month']; ?></td>
                        <td><?php echo $row['year']; ?></td>
                        <td><?php echo $row['fee']; ?></td>
                        <td><?php echo $row['feemonth']; ?></td>

                        <td style="width: 33px;">
                            <a title="delete" href="Delete.php?id=<?php echo $row['id']; ?>">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>

                        <td style="width: 33px;">
                            <a title="update" href="feeupdate.php?id=<?php echo $row['id']; ?>">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>


                    </tr>
                <?php } ?>

                <!-- Create a new row at the bottom to display the total in the "Fee" column -->
                <tr style="background-color: #ccc; color:green;">
                    <td colspan="7"><strong>Total Fee:</strong></td>
                    <td><strong><?php echo $totalFee; ?></strong></td>
                    <td colspan="4"></td> <!-- Adjust the colspan to match your columns -->
                </tr>

            </table>
        </div>
    <?php } else { ?>
        <p>No records found.</p>
    <?php } ?>
</body>

</html>