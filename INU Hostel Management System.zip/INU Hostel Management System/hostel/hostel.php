<?php require_once('Connections/conn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO fee (sname, fname, degree, sid, status, semester, fee, feemonth, rfid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['sname'], "text"),
                       GetSQLValueString($_POST['fname'], "text"),
                       GetSQLValueString($_POST['degree'], "text"),
                       GetSQLValueString($_POST['sid'], "int"),
                       GetSQLValueString($_POST['status'], "text"),
                       GetSQLValueString($_POST['semester'], "text"),
                       GetSQLValueString($_POST['fee'], "int"),
                       GetSQLValueString($_POST['feemonth'], "text"),
                       GetSQLValueString($_POST['rfid'], "int"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($insertSQL, $conn) or die(mysql_error());
}

mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM fee";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {font-size: 24px}
.style3 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
</head>

<body>
<div align="center">
  <p class="style1"><img src="logo.png" width="120" height="120" /></p>
  <p class="style1">Iqra National University Peshawar <br />
    Hostel Fee Registration </p>
</div>
<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <p>&nbsp;</p>
  <table width="50%" align="center">
    <tr valign="baseline">
      <td><span class="style3">Student Name </span> </td>
      <td><span class="style3">Student Father Name  </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="sname" value="" size="44" /></td>
      <td><input type="text" name="fname" value="" size="44" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Student Degree </span></td>
      <td><span class="style3">Student ID </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="degree" value="" size="44" /></td>
      <td><input type="text" name="sid" value="" size="44" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Student Status </span></td>
      <td><span class="style3">Student Semester </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="status" value="" size="44" /></td>
      <td><input type="text" name="semester" value="" size="44" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td><span class="style3">Enter Hostel Fee</span></td>
      <td><span class="style3">Fee Month </span></td>
    </tr>
    <tr valign="baseline">
      <td><input type="text" name="fee" value="" size="44" /></td>
      <td><input type="text" name="feemonth" value="" size="44" /></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><div align="center"><span class="style3">Student RFID </span></div></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><div align="center">
        <input type="text" name="rfid" value="" size="95" />
      </div></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2"><label>
        <div align="center">
          <input name="submit" type="submit" onclick="MM_validateForm('sname','','R','fname','','R','degree','','R','sid','','RisNum','status','','R','semester','','R','fee','','RisNum','feemonth','','RisNum','rfid','','RisNum');return document.MM_returnValue" value="Submit Record" />
          <input type="reset" name="Reset" value="Reset Form" />
        </div>
      </label></td>
    </tr>
  </table>
  <p>
    <input type="hidden" name="MM_insert" value="form1">
  </p>
</form>
<p>&nbsp;</p>
<p align="center">&nbsp;</p>

<table width="100%" border="1" align="center" cellpadding="2">
  <tr>
    <td>id</td>
    <td>sname</td>
    <td>fname</td>
    <td>degree</td>
    <td>sid</td>
    <td>status</td>
    <td>semester</td>
    <td>fee</td>
    <td>feemonth</td>
    <td>rfid</td>
    <td>sdate</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_Recordset1['id']; ?></td>
      <td><?php echo $row_Recordset1['sname']; ?></td>
      <td><?php echo $row_Recordset1['fname']; ?></td>
      <td><?php echo $row_Recordset1['degree']; ?></td>
      <td><?php echo $row_Recordset1['sid']; ?></td>
      <td><?php echo $row_Recordset1['status']; ?></td>
      <td><?php echo $row_Recordset1['semester']; ?></td>
      <td><?php echo $row_Recordset1['fee']; ?></td>
      <td><?php echo $row_Recordset1['feemonth']; ?></td>
      <td><?php echo $row_Recordset1['rfid']; ?></td>
      <td><?php echo $row_Recordset1['sdate']; ?></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
