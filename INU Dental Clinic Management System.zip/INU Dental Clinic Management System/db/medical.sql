-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2023 at 08:40 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medical`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user`, `pass`) VALUES
(1, 'info@inu.edu.pk', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `address` longtext,
  `procedure` longtext,
  `visit` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `fname`, `lname`, `gender`, `age`, `status`, `phone`, `dob`, `address`, `procedure`, `visit`, `date`) VALUES
(52, 'Shakeel', 'khan', 'Male', '25', 'INU Student', '1234', '--------', '------', 'posterior upper filling with composite \r\n', 'First Visit', '2023-01-17 12:46:28'),
(53, 'Anwar ', 'khan', 'Male', '30', 'INU Student', '1234', '--------', '--------', ' filling ', 'First Visit', '2023-01-17 12:49:58'),
(55, 'Muhammd ', 'adnan', 'Male', '30', 'INU Student', '1234', '--------', '-------', 'upper 1st filling ', 'First Visit', '2023-01-17 12:54:12'),
(56, 'Hina  ', 'khan', 'Female', '25', 'INU Student', '123', '--------', '-----', 'scaling + scalling', 'First Visit', '2023-01-17 12:56:04'),
(57, 'Muhammad ', 'zain', 'Male', '20', 'INU Student', '1234', '--------', '-------', 'composite filling', 'First Visit', '2023-01-17 12:57:13'),
(58, 'Ma am', 'zubaida', 'female', '30', 'faculty', '1234', '--------', '--------', 'complete impression with silicon putty', 'First Visit', '2023-01-17 12:58:08'),
(59, 'Imdadullah', 'khan', 'Male', '26', 'INU Student', '1234', '--------', '--------', 'scaling', 'First Visit', '2023-01-17 12:59:12'),
(60, 'Abdul', 'saboor', 'Male', '25', 'INU Student', '1234', '--------', '--------', 'scalling', 'First Visit', '2023-01-17 12:59:53'),
(61, 'Mamza', 'khan', 'female', '21', 'INU Student', '1234', '--------', '-------', 'scalling', 'First Visit', '2023-01-17 13:00:53'),
(62, 'Ahmed', 'shaib', 'Male', '22', 'INU Student', '1234', '--------', '-------', 'RCT', 'First Visit', '2023-01-17 13:01:39'),
(63, 'Irfan', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-------', 'RCT', 'First Visit', '2023-01-17 13:03:14'),
(64, 'Malaika', 'khan', 'female', '21', 'INU Student', '1234', '--------', '-----------------', 'scaling', 'First Visit', '2023-01-17 13:03:57'),
(65, 'Tufail', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '--------', 'scaling', 'First Visit', '2023-01-17 13:05:30'),
(66, 'Hamza', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '--------------', 'scaling', 'First Visit', '2023-01-17 13:06:24'),
(67, 'Waqas', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '--------', 'scaling', 'First Visit', '2023-01-17 13:07:16'),
(69, 'kaleem', 'khan', 'Male', '25', 'INU Student', '1234', '--------', '-----------', 'composite filling', 'First Visit', '2023-01-17 13:11:34'),
(70, 'Marwa', 'zaib', 'feMale', '24', 'INU Student', '1234', '--------', '-------', 'scaling', 'First Visit', '2023-01-17 13:12:47'),
(71, 'Naila', 'khan', 'female', '23', 'INU Student', '1234', '--------', '--------', 'scaling', 'First Visit', '2023-01-17 13:13:40'),
(72, 'Farman', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '--------', 'scaling', 'First Visit', '2023-01-17 13:15:15'),
(73, 'Imtiyaz', 'khan', 'Male', '35', 'INU Faculty', '123', '--------', '----', 'scaling', 'First Visit', '2023-01-17 13:24:00'),
(74, 'Laiba', 'israr', 'Female', '22', 'INU Student', '123', '--------', '----', 'scaling', 'First Visit', '2023-01-17 13:30:50'),
(75, 'Tehreem', 'shah', 'Male', '22', 'INU Student', '1234', '--------', NULL, 'scaling', 'First Visit', '2023-01-17 13:32:47'),
(76, 'Waleed', 'fareed', 'Male', '28', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-17 13:35:06'),
(77, 'Farhan ', 'ullah', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-17 13:36:58'),
(78, 'Irshad ', 'ullah', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-17 13:39:41'),
(79, 'Attaf', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-17 13:49:46'),
(80, 'Inayat ', 'ullah', 'Male', '42', 'INU Faculty', '1234', '--------', '----', 'RCT', 'First Visit', '2023-01-18 12:46:22'),
(81, 'Imran ', 'khan', 'Male', '42', 'INU Faculty', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 12:47:59'),
(82, 'Muhammad ', 'yonas', 'Male', '23', 'INU Faculty', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 12:49:11'),
(83, 'Waqar', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 12:51:02'),
(84, 'Adnan', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'filling', 'First Visit', '2023-01-18 12:56:17'),
(85, 'Shanzaa', 'hassan', 'Male', '27', 'INU Faculty', '1234', '--------', '---', 'oral examination', 'First Visit', '2023-01-18 12:59:46'),
(86, 'Mahnoor', 'javed ', 'Male', '21', 'INU Student', '1234', '--------', '---', 'oral examination', 'First Visit', '2023-01-18 13:03:16'),
(87, 'Sania ', 'shoaib', 'Male', '22', 'INU Student', '1234', '--------', '---', 'RCT done by Dr shandana', 'First Visit', '2023-01-18 13:04:02'),
(88, 'Hammad', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'oral examination', 'First Visit', '2023-01-18 13:04:41'),
(89, 'Inayat ', 'allah', 'Male', '20', 'INU Student', '1234', '--------', '-----', 'oral examinatiion', 'First Visit', '2023-01-18 13:05:38'),
(90, 'Huzaifa', 'bukhori', 'Male', '23', 'INU Student', '1234', '--------', '--', 'cementation', 'First Visit', '2023-01-18 13:07:20'),
(91, 'Raheem ', 'Abas', 'Male', '23', 'INU Student', '1234', '--------', '----', 'Scaling and poloshing', 'First Visit', '2023-01-18 13:08:50'),
(92, 'Shaheen', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'oral examination', 'First Visit', '2023-01-18 13:09:44'),
(93, 'Fariha', 'khan', 'Female', '28', 'INU Student', '1234', '--------', NULL, 'Scaling', 'First Visit', '2023-01-18 13:10:20'),
(94, 'Muhammad ', 'Ali', 'Male', '35', 'INU Faculty', '1234', '--------', '----', 'composite filling', 'First Visit', '2023-01-18 13:11:44'),
(95, 'Ayaz', 'khan', 'Male', '42', 'INU Faculty', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:12:48'),
(96, 'Faryal ', 'khan', 'Female', '21', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:13:34'),
(97, 'Imdad', 'Allah', 'Male', '23', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:14:25'),
(98, 'Zahid ', 'Ahmad', 'Male', '21', 'INU Student', '1234', '--------', '--', 'scaling', 'First Visit', '2023-01-18 13:15:08'),
(99, 'Waqas', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'scaling /composite filling', 'First Visit', '2023-01-18 13:16:04'),
(100, 'Mehran', 'Allah', 'Male', '24', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:17:16'),
(101, 'Muhammad', 'Yasir', 'Male', '24', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:18:19'),
(102, 'Muhammad ', 'Saeed', 'Male', '37', 'INU Faculty', '1234', '--------', '----', 'filling', 'First Visit', '2023-01-18 13:19:23'),
(103, 'Zaid', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:20:23'),
(104, 'Nazir ', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-01-18 13:22:21'),
(105, 'Faheem', 'Ahmad', 'Male', '36', 'INU Student', '1234', '--------', '----', 'oral examination', 'First Visit', '2023-01-18 13:24:18'),
(106, 'Ihsan', 'khan', 'Male', '45', 'INU Staff', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-01-18 13:25:39'),
(107, 'Hamza', 'khan', 'Male', '22', 'INU Staff', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:27:03'),
(108, 'Shahid', 'Ahmad', 'Male', '22', 'INU Student', '1234', '--------', '---', 'Scaling', 'First Visit', '2023-01-18 13:27:36'),
(109, 'Haroon ', 'rasheed ', 'Male', '25', 'INU Student', '1234', '--------', '---', 'xray', 'First Visit', '2023-01-18 13:28:19'),
(110, 'Ataf', ' Hussain', 'Male', '23', 'INU Student', '1234', '--------', '---', 'Filling', 'First Visit', '2023-01-18 13:29:18'),
(111, 'Sania', 'shoaib', 'Female', '27', 'INU Faculty', '1234', '--------', '----', 'RCT', 'First Visit', '2023-01-18 13:31:00'),
(112, 'Shahab ', 'Afridi', 'Male', '27', 'INU Faculty', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:32:04'),
(113, 'Shahzeb ', 'Hassan', 'Male', '26', 'INU Faculty', '1234', '--------', '---', 'scalling', 'First Visit', '2023-01-18 13:32:47'),
(114, 'Najeeb', 'Nasir', 'Male', '23', 'INU Student', '1234', '--------', '---', 'Scal', 'First Visit', '2023-01-18 13:33:37'),
(115, 'Shahid A', 'Ahmad', 'Male', '22', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:34:55'),
(116, 'Nauman', 'Khan', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:36:39'),
(117, 'Saif ', 'allah', 'Male', '25', 'INU Student', '1234', '--------', '-----', 'filling', 'First Visit', '2023-01-18 13:37:56'),
(118, 'Salman', 'shah', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 13:43:52'),
(119, 'M.owais', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:45:18'),
(120, 'Tariq', 'ullah', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:48:12'),
(121, 'Anwar-ul', 'haq', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:49:38'),
(122, 'Hamad', 'ullah', 'Male', '22', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-01-18 13:51:02'),
(123, 'Aqib', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:52:14'),
(124, 'Abdullah', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-01-18 13:55:23'),
(125, 'Kashif', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-01-18 13:56:58'),
(126, 'Laila', 'alam', 'Female', '30', 'INU Faculty', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 13:58:14'),
(127, 'Junaid', 'ktk', 'Male', '28', 'INU Faculty', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 14:00:17'),
(128, 'Amir', 'aziz', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-01-18 14:01:04'),
(129, 'Amir', 'badsha', 'Male', '45', 'INU Staff', '1234', '--------', '---', 'scaling', 'First Visit', '2023-01-18 14:03:50'),
(130, 'Saddiq', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-01-18 14:04:54'),
(131, 'Mahnoor ', 'khan', 'Female', '19', 'INU Student', '1234', '--------', '---', 'mid line distema occlusal ', 'First Visit', '2023-01-19 15:22:35'),
(132, 'Hashmad ', 'ali', 'Male', '19', 'INU Student', '1234', '--------', '---', 'Scalling ', 'First Visit', '2023-01-19 15:24:05'),
(133, 'Farooq', 'khan', 'Male', '24', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-01-19 15:24:46'),
(134, 'Fahad', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-01-19 15:25:39'),
(135, 'Asim', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-01-19 15:26:24'),
(136, 'Maaz', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'scalling', 'First Visit', '2023-01-19 15:26:50'),
(137, 'Altaf ', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '----', 'sclalling', 'First Visit', '2023-01-19 15:27:25'),
(138, 'Muhammad', 'Yasir', 'Male', '22', 'INU Student', '1234', '--------', '---', 'scalling', 'First Visit', '2023-01-19 15:28:08'),
(139, 'Abdullah', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '---', 'scalling', 'First Visit', '2023-01-19 15:28:42'),
(140, 'Muhammad', 'yaseen', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-01-19 15:29:16'),
(141, 'Ziaul', 'islam', 'Male', '24', 'INU Student', '1234', '--------', '---', 'scalling and filling', 'First Visit', '2023-01-19 15:30:19'),
(142, 'Abdul', 'samad', 'Male', '24', 'INU Student', '1234', '--------', '---', 'scalling and fillng', 'First Visit', '2023-01-19 15:30:59'),
(143, 'Shiraz', 'khan', 'Male', '49', 'INU Student', '1234', '--------', '---', 'scalling ', 'First Visit', '2023-01-19 15:33:13'),
(144, 'Salman', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-01-19 15:34:17'),
(145, 'Kalim ', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '---', 'filling', 'First Visit', '2023-01-19 15:35:05'),
(146, 'Rahman ', 'ali', 'Male', '22', 'INU Student', '1234', '--------', '---', 'filling', 'First Visit', '2023-01-19 15:36:17'),
(147, 'Hamza', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scalling and polishing', 'First Visit', '2023-01-19 15:38:09'),
(148, 'Mosa', '----', 'Male', '24', 'INU Student', '1234', '--------', '---', 'scalling', 'First Visit', '2023-01-19 15:38:46'),
(149, 'Maaz', '----', 'Male', '22', 'INU Student', '1234', '--------', '--', 'scaling', 'First Visit', '2023-01-19 15:42:02'),
(151, 'umar', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-01 11:21:14'),
(152, 'hassan', 'bbb', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scasling and polishing', 'First Visit', '2023-02-01 11:22:56'),
(154, ' Usama', 'dobo', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-01 11:26:33'),
(155, 'Sania ', 'shoaib', 'Female', '26', 'INU Faculty', '1234', '--------', '-----', 'filling', 'First Visit', '2023-02-01 11:28:18'),
(156, 'Abdul ', 'jabir', 'Male', '25', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-02-01 11:29:18'),
(157, 'Ayaz', 'khan', 'Male', '42', 'INU Staff', '1234', '--------', '---', 'filling', 'First Visit', '2023-02-01 11:30:24'),
(158, 'M.sanan', ' zahir', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-01 11:31:18'),
(159, 'Muhammad', 'shahzad', 'Male', '23', 'INU Faculty', '1234', '--------', '---', 'scaling', 'First Visit', '2023-02-01 11:32:13'),
(160, 'Hammad', 'ali', 'Male', '22', 'INU Student', '1234', '--------', '---', 'filling', 'First Visit', '2023-02-01 11:33:12'),
(161, 'Muhammad', 'Ibrahim', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-01 12:52:53'),
(162, 'Nasr', 'ullah', 'Male', '30', 'INU Faculty', '1234', '--------', '----', 'Composite filling', 'First Visit', '2023-02-01 13:05:34'),
(163, 'Salman', 'afridi', 'Male', '18', 'INU Student', '1234', '--------', '-----', 'Scaling', 'First Visit', '2023-02-01 13:08:05'),
(164, 'Salman', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-01 13:09:41'),
(165, 'Bilal', 'shah', 'Male', '25', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-01 13:10:36'),
(166, 'Abdul', 'rehman', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'Scaling', 'First Visit', '2023-02-01 13:11:55'),
(167, 'Ramsha', 'raza', 'Male', '23', 'INU Student', '1234', '--------', '------', 'Scaling', 'First Visit', '2023-02-01 13:13:24'),
(168, 'Semi-ur-', 'rahman', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-02-01 13:14:58'),
(169, 'Muhammad room', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling', 'First Visit', '2023-02-01 13:16:13'),
(170, 'Zia -ur', 'rehman', 'Male', '22', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-02-02 11:42:10'),
(171, 'Saad ', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'Scaling', 'First Visit', '2023-02-03 12:11:25'),
(172, 'Abdullah', '-----', 'Male', '24', 'INU Student', '1234', '--------', '-----', 'filling', 'First Visit', '2023-02-03 12:26:28'),
(173, 'Jbadat', '------', 'Male', '24', 'INU Student', '1234', '------', '----', 'scaling', 'First Visit', '2023-02-03 14:50:38'),
(174, 'Zainab', 'bb', 'Female', '28', 'Outsider', '1234', '--------', 'phase 6 hayatabad', 'RCT procedures is done fee charges 3000', 'First Visit', '2023-02-03 14:58:54'),
(175, 'M idrees ', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-03 14:59:57'),
(176, 'Haris', '----', 'Male', '23', 'INU Student', '1234', '--------', '---', 'filing', 'First Visit', '2023-02-03 15:01:48'),
(177, 'Ayub', 'khan', 'Male', '24', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-03 15:03:30'),
(178, 'Aziz ur', 'rahman', 'Male', '24', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-03 15:04:26'),
(179, 'Waqas', 'ahmed', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scalling', 'First Visit', '2023-02-07 12:02:03'),
(180, 'Jamshid', 'ali', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'scalling', 'First Visit', '2023-02-07 12:03:46'),
(181, 'Ahmed', 'shah', 'Male', '25', 'INU Student', '1234', '--------', '----', 'scalling', 'First Visit', '2023-02-07 12:04:31'),
(182, 'Sikandar', 'bb', 'Male', '25', 'INU Student', '1234', '--------', '-----', 'filling', 'First Visit', '2023-02-07 12:05:08'),
(183, 'Sana', 'u', 'Male', '49', 'outsider', '1234', '--------', 'islamia college', 'RCT (Root canal treatment)3000 paid', 'First Visit', '2023-02-07 12:07:45'),
(184, 'Shahkar', 'bb', 'Male', '18', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-07 12:12:59'),
(185, 'Afaq', 'bb', 'Male', '19', 'INU Student', '1234', '--------', '-----', 'scalling', 'First Visit', '2023-02-07 12:13:43'),
(186, 'Ahsan', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '---', 'scaling', 'First Visit', '2023-02-07 12:14:28'),
(187, 'Hidayat', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-07 12:15:23'),
(188, 'Qirat', 'amin', 'Male', '23', 'INU Student', '1234', '--------', '---', 'filling', 'First Visit', '2023-02-07 12:16:58'),
(189, 'Emaan', 'asif', 'Female', '21', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-07 12:18:57'),
(190, 'Iqra', 'sadiq', 'Female', '19', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-07 12:21:41'),
(191, 'Muhammad', 'abbas', 'Male', '23', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-02-07 12:23:38'),
(192, 'Anwar', 'ul haq', 'Male', '24', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-02-07 12:24:31'),
(193, 'Muhammad', 'bilal', 'Male', '21', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-02-07 12:25:14'),
(194, 'Mustafa', 'khan', 'Male', '18', 'INU Student', '1234', '--------', '----', 'filling and scaling', 'First Visit', '2023-02-07 12:26:12'),
(195, 'Beenish', 'bb', 'Female', '33', 'INU Faculty', '1234', '--------', '-----', 'filling', 'First Visit', '2023-02-07 12:27:43'),
(196, 'Azan', 'murtajiz', 'Male', '20', 'INU Student', '1234', '--------', '------', 'scaling and polishing', 'First Visit', '2023-02-07 12:28:57'),
(197, 'Laiba', 'aaa', 'Female', '20', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-02-07 12:30:16'),
(198, 'Mehar', 'ali', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling and polishing', 'First Visit', '2023-02-07 12:31:22'),
(199, 'Amir', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'scaling and polishing', 'First Visit', '2023-02-07 12:32:42'),
(200, 'Hamid ', 'wazir', 'Male', '22', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-02-07 12:33:49'),
(201, 'Syed', 'arbab', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scaling and polishing', 'First Visit', '2023-02-07 12:34:44'),
(202, 'Zainab', 'aaa', 'Female', '28', 'Outsider', '1234', '--------', 'phase6 hayatabad', 'RCT (root canal treatment) 3000 paid', 'First Visit', '2023-02-07 12:39:26'),
(203, 'Muhammad', 'yaseen', 'Male', '20', 'INU Student', '1234', '----', '---', 'scaling', 'First Visit', '2023-02-07 12:40:42'),
(204, 'Walli', 'ullah', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-07 12:42:12'),
(205, 'Ali', 'bb', 'Male', '33', 'INU Faculty', '1234', '--------', '----', 'scaling', 'First Visit', '2023-02-07 12:46:34'),
(206, 'Tehreem', 'aaaa', 'Female', '28', 'INU Faculty', '1234', '--------', '----', 'scaling and polishing and filling', 'First Visit', '2023-02-07 12:48:10'),
(207, 'Hassan', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'filling', 'First Visit', '2023-02-07 12:51:08'),
(208, 'Tahir', 'Hassan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Filling', 'First Visit', '2023-02-09 12:57:09'),
(209, 'Kamran', 'Khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling +Polishing', 'First Visit', '2023-02-09 13:01:17'),
(210, 'Tauqeer', 'Nasir', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:02:54'),
(211, 'Anwar ul', 'Haq', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Filling', 'First Visit', '2023-02-09 13:05:04'),
(212, 'Habib', 'bbb', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:07:11'),
(213, 'Zawar', 'Hussain', 'Male', '22', 'INU Student', '1234', '------', '-----', 'Xray', 'First Visit', '2023-02-09 13:08:18'),
(214, 'Khurram ', 'Imtiaz', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'Examination', 'First Visit', '2023-02-09 13:11:04'),
(215, 'Muheed', 'Khalid', 'Male', '24', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:13:44'),
(216, 'Ahmad', 'Ali', 'Male', '25', 'INU Student', '1234', '--------', '-----', 'Scaling+polihing', 'First Visit', '2023-02-09 13:14:35'),
(217, 'Fayaz', 'Ali', 'Male', '24', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:15:31'),
(218, 'Muhamma', 'Adnan', 'Male', '24', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:16:46'),
(219, 'Uzair', 'Ali', 'Male', '23', 'INU Student', '1234', '--------', '----', 'Scaling=polishing', 'First Visit', '2023-02-09 13:17:26'),
(220, 'Zuhaib', 'Ahmad', 'Male', '23', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:18:18'),
(221, 'Qaisar', 'Ali', 'Male', '23', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:19:38'),
(222, 'Muhammad', 'Uzair', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Filling', 'First Visit', '2023-02-09 13:21:15'),
(223, 'Muhammad', 'Sulaiman', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling', 'First Visit', '2023-02-09 13:22:28'),
(224, 'Sufyan', 'bbbb', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:23:45'),
(225, 'Junaid', 'bbb', 'Male', '21', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-09 13:24:29'),
(226, 'M.Abbas', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '-----', 'Scaling +polishing', 'First Visit', '2023-02-10 14:44:03'),
(227, 'Abdullah ', 'khan', 'Male', '21', 'INU Student', '1234', '--------', '-----', 'Scaling +polishing', 'First Visit', '2023-02-10 14:53:01'),
(228, 'Raheel', 'Aslam', 'Male', '21', 'INU Student', '1234', '--------', '----', 'Scaling+polishing', 'First Visit', '2023-02-10 14:56:07'),
(229, 'Asim', 'bbb', 'Male', '21', 'INU Student', '1234', '--------', '----', 'filling\r\n', 'First Visit', '2023-02-10 14:57:00'),
(250, 'Usama', 'Zubair', 'Male', '22', 'INU Student', '1234', '--------', '----\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', '\r\n\r\n\r\n\r\n\r\n\r\nScaling+Polishing\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 'First Visit', '2023-02-10 14:58:35'),
(269, 'Halil', 'khan', 'Male', '32', 'INU Student', '1234', '--------', '-----', 'Scaling+polishing', 'First Visit', '2023-02-10 14:59:36'),
(270, 'Misbah', 'Ullah', 'Male', '38', 'INU Student', '1234', '--------', '----', 'Extraction', 'First Visit', '2023-02-10 15:00:22'),
(271, 'Zuhaib', 'Ahmad', 'Male', '21', 'INU Student', '1234', '--------', '----', 'Filling', 'First Visit', '2023-02-10 15:01:00'),
(272, 'yahya', 'BV', 'Male', '22', 'INU Student', '1234', '13-Feb-2023', '----', 'Scaling', 'First Visit', '2023-02-13 14:54:15'),
(273, 'Anwar ', 'Ul Haq', 'Male', '25', 'INU Student', '1234', '13-02-2023', 'Peshawer', 'Polishing', 'First Visit', '2023-02-13 14:55:51'),
(274, 'Ziagham', 'Abas', 'Male', '30', 'INU Staff', '1234', '13-02-2023', '----', 'Scaling &Polishing', 'First Visit', '2023-02-13 14:57:36'),
(275, 'DR Qaiser ', 'Muhammad', 'Male', '29', 'INU Staff', '1234', '----', '---', 'Polishing ', 'First Visit', '2023-02-13 14:59:04'),
(276, 'Muhammad', 'Afaq', 'Male', '19', 'INU Student', '1234', '----', '------', 'Scaling ', 'First Visit', '2023-02-14 12:30:36'),
(277, 'Muhammad', 'Ahsan', 'Male', '20', 'INU Student', '1234', '----', '---', 'Scaling+ Polishing', 'First Visit', '2023-02-14 12:32:39'),
(278, 'Asad', 'Ameen', 'Male', '21', 'INU Student', '1234', '----', '--', 'Scaling+ polishing', 'First Visit', '2023-02-14 12:33:15'),
(279, 'Inam', 'Ullah', 'Male', '21', 'INU Student', '1234', '----', '----', 'Scaling+Polishing', 'First Visit', '2023-02-14 12:33:53'),
(280, 'Farhad', '--', 'Male', '21', 'INU Student', '1234', '--------', '---', 'Scaling+Polishing', 'First Visit', '2023-02-14 12:34:40'),
(281, 'Zuhaib', '--', 'Male', '27', 'INU Student', '1234', '----', '---', 'X-ray', 'First Visit', '2023-02-14 12:35:39'),
(282, 'Qaiser', 'Ali', 'Male', '23', 'INU Student', '1234', '---', '---', 'Scaling + polishing + filling', 'First Visit', '2023-02-15 11:01:49'),
(283, 'Rizwan', '--', 'Male', '23', 'INU Faculty', '1234', '------', '---', 'Oral Examination', 'First Visit', '2023-02-15 11:02:41'),
(284, 'Rida', '---', 'Male', '25', 'INU Student', '1234', '--', '---', 'Oral Examination', 'First Visit', '2023-02-15 11:03:17'),
(285, 'Mehar', '--', 'Male', '25', 'INU Staff', '1234', '--', '---Filling', NULL, 'First Visit', '2023-02-15 11:03:54'),
(286, 'Muhammad', 'Bilal', 'Male', '20', 'INU Faculty', '1234', '--', '---', 'X Ray', 'First Visit', '2023-02-15 11:04:50'),
(287, 'sir', 'sheraz', 'Male', '50', 'INU Staff', '1234', '--', '---', 'Scaling', 'First Visit', '2023-02-15 12:02:03'),
(288, 'Rehmat', 'khan', 'Male', '37', 'INU Staff', '1234', '---', '--', 'SCaling', 'First Visit', '2023-02-15 12:03:04'),
(289, 'Syed ', 'Shahzeb', 'Male', '25', 'INU Student', '2147483647', '07-07-2001', '----', 'Oral Exam', 'First Visit', '2023-02-16 10:53:21'),
(290, 'Riwana', '--', 'Male', '22', 'INU Student', '1234', '----', '---', 'Oral Examination', 'First Visit', '2023-02-20 14:13:42'),
(291, 'Mehar', '---', 'Male', '25', 'INU Student', '1234', '---', '---', 'Filling', 'First Visit', '2023-02-20 14:14:16'),
(292, 'M ', 'Bilil', 'Male', '28', 'INU Student', '1234', '--', '---', 'Scaling+Filling', 'First Visit', '2023-02-20 14:15:02'),
(293, 'Zulfiqar', '---', 'Male', '20', 'INU Student', '1234', '---', '---', 'Scaling + filling', 'First Visit', '2023-02-20 14:16:20'),
(294, 'Rehan', 'ullah', 'Male', '31', 'INU Faculty', '1234', '---', '----', 'scaling+polishing', 'First Visit', '2023-02-20 14:36:27'),
(295, 'Syed', 'shehzad', 'Male', '25', 'INU Student', '1234', '----', '----', NULL, 'First Visit', '2023-02-20 14:38:12'),
(296, 'Maqsood', 'ur rehman', 'Male', '22', 'INU Student', '1234', '---', '---', 'scaling', 'First Visit', '2023-02-20 14:39:40'),
(297, 'Hamza', 'gull', 'Male', '20', 'INU Student', '1234', '----', '----', 'scaling', 'First Visit', '2023-02-20 14:40:33'),
(298, 'Qaiser', 'ali', 'Male', '23', 'INU Student', '1234', '----', '----', 'filling', 'First Visit', '2023-02-20 14:41:26'),
(299, 'Mehar ', 'jabeen', 'Male', '27', 'INU Student', '1234', '----', '----', 'examination', 'First Visit', '2023-02-20 14:42:39'),
(300, 'Rida', 'ali', 'Female', '25', 'INU Student', '1234', '----', '----', 'scaling', 'First Visit', '2023-02-20 14:44:00'),
(301, 'Muhammad', 'majid', 'Male', '33', 'INU Faculty', '1234', '----', '----', 'scaling', 'First Visit', '2023-02-20 14:45:02'),
(302, 'Louqman', 'ullah', 'Male', '23', 'INU Student', '1234', '----', '---', 'scaling', 'First Visit', '2023-02-20 14:46:31'),
(303, 'Laiba', 'khan', 'Female', '24', 'INU Student', '1234', '------', '-----', '\r\nScaling', 'First Visit', '2023-02-20 15:06:29'),
(304, 'Farhan', 'ullah', 'Male', '26', 'INU Student', '1234', '------', '----', 'Scaling', 'First Visit', '2023-02-20 15:13:18'),
(305, 'Azhad', 'niaz', 'Male', '24', 'INU Student', '1234', '...', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:26:22'),
(306, 'Nazir', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:41:39'),
(307, 'Umar', 'ayaz', 'Male', '21', 'INU Student', '1234', '----', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:42:48'),
(308, 'Ali', 'wijdan', 'Male', '24', 'INU Student', '1234', '--', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:44:14'),
(309, 'Atif', 'khan', 'Male', '25', 'INU Student', '1234', '---', '----', 'scaling', 'First Visit', '2023-02-21 14:44:39'),
(310, 'Haseeb', 'khan', 'Male', '20', 'INU Student', '1234', '--------', NULL, 'filling', 'First Visit', '2023-02-21 14:46:31'),
(311, 'Saeed', 'ullah', 'Male', '23', 'INU Student', '1234', '------', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:51:18'),
(312, 'Salman', 'afridi', 'Male', '20', 'INU Student', '1234', '----', '----', 'scaling and polishing', 'First Visit', '2023-02-21 14:52:22'),
(313, 'Baitullah', 'khan', 'Male', '67', 'Outsider', '1234', '------------', '--', 'Scaling', 'First Visit', '2023-02-22 11:41:13'),
(314, 'Arbaz ', 'khan', 'Male', '22', 'INU Student', '1234', '------------', '--', 'Composite Filling', 'First Visit', '2023-02-22 12:13:36'),
(315, 'Akram', 'khan', 'Male', '21', 'INU Student', '1234', '------', '---', 'Scaling', 'First Visit', '2023-02-22 14:56:33'),
(316, 'Muhammad ', 'Fahad', 'Male', '22', 'INU Student', '1234', '---', '-----', 'Filling', 'First Visit', '2023-02-22 14:58:41'),
(317, 'Saeed', 'khan', 'Male', '23', 'INU Student', '1234', '------', '---', 'scaling', 'First Visit', '2023-02-22 15:01:16'),
(318, 'Mariam', 'abbas', 'Male', '29', 'INU Faculty', '1234', '--------', '-----', 'Scaling +  Polishing', 'First Visit', '2023-02-23 11:40:36'),
(319, 'Mohsin', 'khan', 'Male', '25', 'INU Faculty', '1234', '--------', '------', 'Oral examination pocket dressing,', 'First Visit', '2023-02-23 13:29:21'),
(320, 'Hammad', 'khan', 'Male', '23', 'INU Student', '1234', '------', '-----', 'Scaling', 'First Visit', '2023-02-23 13:48:09'),
(321, 'Muhammad', 'Adnan', 'Male', '21', 'INU Student', '1234', '---', '----', 'Filling', 'First Visit', '2023-02-23 13:51:11'),
(322, 'Wajdan', 'Ahmad', 'Male', '23', 'INU Student', '1234', '---', '----', 'Scaling+ polishing', 'First Visit', '2023-02-23 13:54:12'),
(323, 'Awais', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling+Polishing', 'First Visit', '2023-02-23 13:56:40'),
(324, 'Umar', 'Zaib', 'Male', '21', 'INU Student', '1234', '---', '----', 'Pocket Dressing', 'First Visit', '2023-02-23 14:01:43'),
(325, 'Sadiq', 'khan', 'Male', '22', 'INU Student', '1234', '-----', '----------------------', 'scaling', 'First Visit', '2023-03-14 13:24:25'),
(326, 'AIi', 'hassan', 'Male', '21', 'INU Student', '1234', '--------', '----', 'scaling and polishing', 'First Visit', '2023-03-14 13:27:29'),
(327, 'Beenish', 'khan', 'Female', '33', 'INU Faculty', '1234', '--------', '----', 'filling', 'First Visit', '2023-03-14 13:33:05'),
(328, 'Tauqeer', 'khan', 'Male', '22', 'INU Student', '1234', '----', '----', 'filling', 'First Visit', '2023-03-14 13:34:28'),
(329, 'Fahad', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-03-16 13:59:32'),
(330, 'masood ', 'khan', 'Male', '23', 'INU Student', '1234', '--------', '--', 'scalling', 'First Visit', '2023-03-16 14:00:10'),
(331, 'Mehmad', 'Hassan', 'Male', '23', 'INU Student', '1234', '--------', '----', 'scalling +filling', 'First Visit', '2023-03-16 14:01:54'),
(332, 'Farhan', 'khan', 'Male', '26', 'INU Student', '1234', '-------', '----', 'scalling', 'First Visit', '2023-03-16 14:03:08'),
(333, 'Muhammad', 'fawad khan', 'Male', '22', 'INU Student', '1234', '--------', '-----', 'oral examination', 'First Visit', '2023-03-16 14:06:23'),
(334, 'Tahir', 'hassan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'filling', 'First Visit', '2023-03-16 14:07:16'),
(335, 'Shoib', 'akhtar', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'filling', 'First Visit', '2023-03-16 14:08:39'),
(336, 'Sir faheem', 'ahmad', 'Male', '38', 'INU Faculty', '2147483647', '--------', '----', 'scaling +polishing', 'First Visit', '2023-03-20 12:55:30'),
(337, 'Khurshid', 'Anwer', 'Male', '22', 'INU Student', '1234', '--------', '---', 'Filling', 'First Visit', '2023-03-20 14:52:46'),
(338, 'Masood', 'Khan', 'Male', '24', 'INU Student', '1234', '--', '---', 'Scaling = Polishing', 'First Visit', '2023-03-20 14:53:39'),
(339, 'Raheem', 'Abass', 'Male', '34', 'INU Student', '1234', '------', '---', 'Scaling - POlishing', 'First Visit', '2023-03-20 14:54:28'),
(340, 'Muhammad', 'Asif', 'Male', '23', 'INU Student', '1234', '---', '--', 'Scaling', 'First Visit', '2023-03-20 14:55:24'),
(341, 'Jehad', 'ullah', 'Male', '23', 'INU Student', '1234', '--', '--', 'Scalig', 'First Visit', '2023-03-20 14:56:33'),
(342, 'Saeed', 'khan', 'Male', '48', 'INU Faculty', '1234', '--', '---', 'Deep Scaling', 'First Visit', '2023-03-20 14:57:35'),
(343, 'Muhammad', 'arif', 'Male', '40', 'INU Faculty', '1234', '---', '--', 'Restoration', 'First Visit', '2023-03-20 14:58:23'),
(344, 'Asim', 'khan', 'Male', '22', 'INU Student', '1234', '---', '--', 'Scailng', 'First Visit', '2023-03-20 14:58:58'),
(345, 'Amir ', 'Suhail', 'Male', '30', 'INU Student', '1234', '--', '-----', 'filling', 'First Visit', '2023-03-20 14:59:36'),
(346, 'Aiman', 'rahim', 'Male', '23', 'INU Student', '1234', '--', '---', 'filling', 'First Visit', '2023-03-20 15:00:09'),
(347, 'Shah', 'noor', 'Male', '22', 'INU Student', '1234', '--', '---', 'scaling', 'First Visit', '2023-03-20 15:00:50'),
(348, 'Junaid', 'khan', 'Male', '19', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-03-20 15:01:39'),
(349, 'Muhammad', 'Abdullah', 'Male', '21', 'INU Student', '1234', '--', '---', 'Scaling', 'First Visit', '2023-03-20 15:02:26'),
(350, 'Muhammad', 'Uzair', 'Male', '22', 'INU Student', '1234', '--', '--', 'Polishing', 'First Visit', '2023-03-20 15:03:09'),
(351, 'Mahnoor', 'shahid', 'Male', '21', 'INU Student', '1234', '--', '--', 'scaling\r\n', 'First Visit', '2023-03-20 15:03:39'),
(352, 'Sania', 'gohar', 'Male', '23', 'INU Student', '1234', '---', '---', 'Scaling\r\n', 'First Visit', '2023-03-20 15:04:05'),
(353, 'Umair ', 'khan', 'Male', '20', 'INU Student', '1234', '---', '-', 'Scaling  Filling', 'First Visit', '2023-03-20 15:04:37'),
(354, 'amir', 'khan', 'Male', '21', 'INU Student', '1234', '--', '--', 'Scaling', 'First Visit', '2023-03-20 15:05:04'),
(355, 'Waseem', 'sajad', 'Male', '20', 'INU Student', '1234', '--', '--', 'filling', 'First Visit', '2023-03-20 15:05:31'),
(356, 'Sir', 'Fahim', 'Male', '38', 'INU Staff', '1234', '---', '---', 'Scaling\r\n', 'First Visit', '2023-03-20 15:06:19'),
(357, 'Faisal', 'hayat', 'Male', '21', 'INU Student', '1234', '--------', '--', 'Scaling\r\n', 'First Visit', '2023-03-20 15:06:48'),
(359, 'Areeb', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-04-04 09:48:30'),
(360, 'Areesha', 'azrung', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-04-04 10:04:23'),
(361, 'Madiha', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '------', 'Scaling +polishing', 'First Visit', '2023-04-04 10:08:16'),
(362, 'Noor', 'rehman', 'Male', '65', 'Outsider', '1234', '--------', '---', 'Extraction  fee charged(1000)', 'First Visit', '2023-04-04 10:13:20'),
(363, 'Hassan', 'Aziz', 'Male', '30', 'Outsider', '1234', '--------', '---', 'Cementation fee charged(500)', 'First Visit', '2023-04-04 10:18:33'),
(364, 'Mariam', 'Abbas', 'Female', '30', 'INU Faculty', '123', '.....', '......', 'Oral eaxmination', 'First Visit', '2023-04-28 15:35:34'),
(365, 'Waseem', 'khan', 'Male', '30', 'INU Faculty', '1234', '--------', '....', 'Oral examination', 'First Visit', '2023-04-28 15:40:44'),
(366, 'Mariam ', 'abbas', 'Female', '29', 'INU Faculty', '1234', '--------', '----', 'oral examination', 'First Visit', '2023-05-04 13:06:16'),
(368, 'Muhammad', 'Atif', 'Male', '24', 'INU Student', '2147483647', '--------', '-----', 'Scaling', 'First Visit', '2023-05-09 13:34:23'),
(370, 'Afzal', 'Shsh', 'Male', '34', 'INU Faculty', '1234', '--------', '.....', 'Oral exam', 'First Visit', '2023-05-29 13:58:08'),
(371, 'Abd', 'Ullah', 'Male', '24', 'INU Student', '1234', '--------', '......', 'Oral exam', 'First Visit', '2023-05-29 13:59:24'),
(379, 'Shah', 'hussain', 'Male', '23', 'INU Student', '1234', '--------', '.......', 'Scaling', 'First Visit', '2023-05-29 14:00:41'),
(383, 'Danish', 'khan', 'Male', '19', 'INU Student', '1234', '--------', '......', 'polishing', 'First Visit', '2023-05-29 14:01:37'),
(384, 'Ubaid', 'khan', 'Male', '20', 'INU Student', '1234', '--------', '.....', 'Scaling', 'First Visit', '2023-05-29 14:02:28'),
(385, 'Inam ', 'ullah', 'Male', '21', 'INU Student', '1234', '--------', '.......', 'Scaling', 'First Visit', '2023-05-29 14:03:14'),
(386, 'Muhammad', 'Israfeel', 'Male', '22', 'INU Student', '1234', '--------', '......', 'Scaling', 'First Visit', '2023-05-29 14:04:33'),
(387, 'Neelo', 'gul', 'Male', '23', 'INU Student', '1234', '--------', '.............\r\n\r\n\r\n', 'Scaling', 'First Visit', '2023-05-29 14:06:00'),
(388, 'Jalal', 'bbbbb', 'Male', '22', 'INU Student', '1234', '--------', '....', 'Scaling', 'First Visit', '2023-05-29 14:07:07'),
(389, 'Irfan', 'bbbbb', 'Male', '22', 'INU Student', '1234', '--------', '....', 'Scaling', 'First Visit', '2023-05-29 14:08:41'),
(390, 'Sheraz', 'bbb', 'Male', '28', 'INU Student', '1234', '--------', '..........', 'Scaling', 'First Visit', '2023-05-29 14:31:34'),
(391, 'Yaseen', 'shah', 'Male', '21', 'INU Student', '1234', '--', '.....', '\r\n\r\n\r\nFilling', 'First Visit', '2023-05-29 14:32:49'),
(392, 'Subhan', 'Allah', 'Male', '23', 'INU Student', '1234', '----', '......', 'filling', 'First Visit', '2023-05-29 14:34:02'),
(393, 'Subhan', 'Allah', 'Male', '23', 'INU Student', '1234', '----', '......', 'filling', 'First Visit', '2023-05-29 14:34:05'),
(394, 'Rahmat', 'bbb', 'Male', '43', 'INU Faculty', '1234', '--', '.....', 'scaling', 'First Visit', '2023-05-29 14:36:06'),
(395, 'Rahat', 'bbb', 'Male', '17', 'INU Staff', '1234', '------', '....', 'scaling', 'First Visit', '2023-05-29 14:36:57'),
(396, 'Amir', 'hamza', 'Male', '22', 'INU Student', '1234', '---', '...', 'scaling', 'First Visit', '2023-05-29 14:37:43'),
(397, 'Nauman', 'khan', 'Male', '22', 'INU Student', '1234', '------', '.....', 'scaling', 'First Visit', '2023-05-29 14:39:00'),
(398, 'Shahzeb', 'khan', 'Male', '26', 'INU Student', '1234', '---', '....', 'scaling', 'First Visit', '2023-05-29 14:39:49'),
(399, 'Nazir', 'khan', 'Male', '21', 'INU Student', '1234', '----', '....', 'filling', 'First Visit', '2023-05-29 14:40:28'),
(400, 'Farhan', 'khan', 'Male', '25', 'INU Student', '1234', '------', '...', 'scaling', 'First Visit', '2023-05-29 14:41:17'),
(401, 'Muaz', 'irfan', 'Male', '23', 'INU Student', '1234', '------', '....', 'filling', 'First Visit', '2023-05-29 14:42:43'),
(402, 'Aqib', 'khan', 'Male', '23', 'INU Student', '1234', '---', '......', 'filling\r\n', 'First Visit', '2023-05-29 14:43:24'),
(403, 'Masood', 'khan', 'Male', '24', 'INU Student', '1234', '----', '...', 'scaling', 'First Visit', '2023-05-29 14:44:09'),
(404, 'Nazir', 'khan', 'Male', '21', 'INU Student', '1234', '------', '....', 'filling', 'First Visit', '2023-05-29 14:45:16'),
(405, 'Saeed', 'Karim', 'Male', '31', 'INU Staff', '1234', '------', '...', 'filling', 'First Visit', '2023-05-29 14:46:07'),
(406, 'Asim', 'Ali', 'Male', '24', 'INU Student', '1234', '--------', '....', 'filling', 'First Visit', '2023-05-29 14:48:11'),
(407, 'Irshad', 'ali', 'Male', '22', 'INU Student', '1234', '------', '.....', 'scaling', 'First Visit', '2023-05-29 14:50:34'),
(408, 'Madiha', 'shah', 'Female', '22', 'INU Student', '1234', '------', '.....', 'scaling', 'First Visit', '2023-05-29 14:59:38'),
(409, 'Farhan', 'ahmad', 'Male', '28', 'INU Student', '1234', '--------', '......', 'scaling', 'First Visit', '2023-05-29 15:02:10'),
(410, 'Farhan', 'ahmad', 'Male', '28', 'INU Student', '1234', '--------', '......', 'scaling', 'First Visit', '2023-05-29 15:02:27'),
(413, 'Aqib', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '.....', 'scaling', 'First Visit', '2023-05-29 15:05:29'),
(414, 'Inam', 'ullah', 'Male', '21', 'INU Student', '1234', '--------', '......', 'Scaling', 'First Visit', '2023-05-29 15:06:33'),
(415, 'Talha', 'saeed', 'Male', '20', 'INU Student', '1234', '--------', '......', 'scaling', 'First Visit', '2023-05-29 15:07:22'),
(416, 'Sibghat', 'shah', 'Male', '21', 'INU Student', '1234', '--------', '...', 'scaling', 'First Visit', '2023-05-29 15:08:20'),
(417, 'Aiman', 'sheraz', 'Male', '24', 'INU Student', '1234', '--------', '.....', 'filling', 'First Visit', '2023-05-29 15:09:13'),
(419, 'Gul', 'zar', 'Male', '23', 'INU Student', '1234', '--------', '.......', 'exam', 'First Visit', '2023-05-29 15:10:25'),
(424, 'Muhammad', 'junaid', 'Male', '24', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-09-22 11:19:04'),
(425, 'sifat', 'ullah', 'Male', '22', 'INU Student', '1234', '------------', '-----', 'oral examingtion', 'First Visit', '2023-09-22 11:21:49'),
(426, 'asad', 'ameer', 'Male', '24', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-09-22 11:23:29'),
(427, 'Tahani', 'shakoor', 'Male', '22', 'INU Student', '1234', '--------', '----', 'scaling', 'First Visit', '2023-09-22 11:29:47'),
(428, 'Muhammad', 'danan', 'Male', '23', 'INU Student', '1234', '--------', '-----', 'scaling', 'First Visit', '2023-09-22 11:32:04'),
(429, 'Muhammad', 'ail', 'Male', '22', 'INU Student', '1234', '--------', '---', 'composite', 'First Visit', '2023-09-22 11:34:52'),
(430, 'Muhammad', 'zubair', 'Male', '22', 'INU Student', '2147483647', '--------', '----', 'polishing', 'First Visit', '2023-09-22 11:36:41'),
(431, 'Awais', 'kochaz', 'Male', '20', 'INU Student', '1234', '--------', '-----', 'Extraction fee/500', 'First Visit', '2023-09-22 12:17:49'),
(438, 'Seyab', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-09-28 11:19:53'),
(439, 'Omer', 'khan', 'Male', '25', 'INU Student', '1234', '--------', '----', 'Scaling+Polising', 'First Visit', '2023-09-28 11:22:09'),
(440, 'Omer', 'khan', 'Male', '25', 'INU Student', '1234', '--------', '----', 'Scaling+Polising', 'First Visit', '2023-09-28 11:22:16'),
(441, 'Nazir', 'khan', 'Male', '22', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-09-28 11:25:43'),
(444, 'abdul', 'saeed', 'Male', '25', 'INU Student', '1234', '--------', '----', 'Scaling', 'First Visit', '2023-09-28 11:29:58'),
(445, 'Rahat', 'ullah', 'Male', '18', 'INU Staff', '1234', '--------', '-----', 'RCT', 'First Visit', '2023-09-28 11:32:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=447;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
