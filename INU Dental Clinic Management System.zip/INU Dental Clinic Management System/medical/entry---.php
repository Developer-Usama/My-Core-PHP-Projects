<?php require_once('Connections/conn.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO registration (fname, lname, gender, age, status, phone, dob, address, `procedure`, visit) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['fname'], "text"),
                       GetSQLValueString($_POST['lname'], "text"),
                       GetSQLValueString($_POST['gender'], "text"),
                       GetSQLValueString($_POST['age'], "text"),
                       GetSQLValueString($_POST['status'], "text"),
                       GetSQLValueString($_POST['phone'], "text"),
                       GetSQLValueString($_POST['dob'], "text"),
                       GetSQLValueString($_POST['address'], "text"),
                       GetSQLValueString($_POST['procedure'], "text"),
                       GetSQLValueString($_POST['visit'], "text"));

  mysql_select_db($database_conn, $conn);
  $Result1 = mysql_query($insertSQL, $conn) or die(mysql_error());
}

mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM registration";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Registration Form</title>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
}
.style2 {font-size: 24px}
.style7 {font-family: Arial, Helvetica, sans-serif; font-size: 14; }
.style8 {font-size: 14}
-->
</style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
  <script>
<!--
$( function() {
    $( "#datepicker" ).datepicker();
  } );

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
  <style type="text/css">
<!--
.style9 {font-family: Arial, Helvetica, sans-serif}
.style10 {color: #FFFFFF}
.style11 {font-family: Arial, Helvetica, sans-serif; color: #FFFFFF; }
-->
  </style>
</head>
</head>

<body>
<div align="center" class="style1">
  <p class="style2">IQRA NATIONAL UNIVERSITY DENTAL CLINIC </p>
  <p><img src="logo.png" width="131" height="131" /></p>
  <p>Patient Information Form </p>
</div>

<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table width="50%" align="center">
    <tr valign="baseline">
      <td valign="middle"><span class="style7">First Name:</span></td>
      <td valign="middle"><span class="style7">Last Name: </span></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle"><input name="fname" type="text" size="50" /></td>
      <td valign="middle"><input name="lname" type="text" size="50" /></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle">&nbsp;</td>
      <td valign="middle">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td valign="middle"><span class="style7">Age:</span></td>
      <td valign="middle"><span class="style7">Date of Birth: </span></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle"><input name="age" type="text" size="50" /></td>
      <td valign="middle"><input name="dob" id="datepicker" size="50" /></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle"><span class="style8"></span></td>
      <td valign="middle"><span class="style8"></span></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle">&nbsp;</td>
      <td valign="middle"><span class="style7">Phone:</span></td>
    </tr>
    <tr valign="baseline">
      <td valign="middle"><span class="style7">
        Gender:
        <input name="gender" type="radio" value="Male" checked="checked" />
Male  
<input type="radio" name="gender" value="Female" />
Female</span></td>
      <td valign="middle"><input name="phone" type="text" size="50" />      </td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style8"></span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style8"><span class="style7">
        Patient Status: 
              <select name="status">
          <option value="INU Student" <?php if (!(strcmp("INU Student", ""))) {echo "SELECTED";} ?>>INU Student</option>
          <option value="INU Faculty" <?php if (!(strcmp("INU Faculty", ""))) {echo "SELECTED";} ?>>INU Faculty</option>
          <option value="INU Staff" <?php if (!(strcmp("INU Staff", ""))) {echo "SELECTED";} ?>>INU Staff</option>
          <option value="Outsider" <?php if (!(strcmp("Outsider", ""))) {echo "SELECTED";} ?>>Outsider</option>
        </select>
      </span></span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle">&nbsp;</td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style7">Patient Address:</span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style7">
        <textarea name="address" cols="88" rows="5"></textarea>
      </span> </td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style7">Procedure:</span></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><span class="style7">
        <textarea name="procedure" cols="88" rows="5"></textarea>
      </span> </td>
    </tr>
    <tr valign="baseline">
      <td colspan="2" valign="middle"><table width="543%">
        <tr>
          <td class="style7">&nbsp;</td>
        </tr>
        <tr>
          <td class="style7"><input name="visit" type="radio" value="First Visit" checked="checked" />
First Visit
  <input type="radio" name="visit" value="Second Visit" />
Second Visit
<input type="radio" name="visit" value="Third Visit" />
Third Visit
<input type="radio" name="visit" value="Forth Visit" />
Forth Visit
<input type="radio" name="visit" value="Fifth Visit" />
Fifth Visit</td>
        </tr>
        <tr>
          <td class="style7">&nbsp;</td>
        </tr>
      </table></td>
    </tr>
    <tr valign="baseline">
      <td colspan="2">
        <div align="left">
          <input name="submit" type="submit" class="style7" onclick="MM_validateForm('fname','','R','lname','','R','age','','RisNum');return document.MM_returnValue" value="Submit Record" />
          &nbsp; 
          <input name="Reset" type="reset" value="Reset Record" />
        </div></td>
    </tr>
  </table>
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p>&nbsp;</p>

<?php if ($totalRows_Recordset1 > 0) { // Show if recordset not empty ?>
  <table border="1" align="center" cellpadding="5" cellspacing="5" bordercolor="#000000">
    <tr bgcolor="#333333">
      <td><div align="center" class="style10"><span class="style9">S.No</span></div></td>
      <td><span class="style11">First Name </span></td>
      <td><span class="style11">Last Name </span></td>
      <td><span class="style11">Sex</span></td>
      <td><span class="style11">Age</span></td>
      <td><span class="style11">Patient Type </span></td>
      <td><span class="style11">Phone#</span></td>
      <td><span class="style11">DOB</span></td>
      <td><span class="style11">Address</span></td>
      <td><span class="style11">Procedure</span></td>
      <td><span class="style11">Visit</span></td>
      <td colspan="3"><span class="style11">Visit Date </span></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><div align="center"><span class="style9"><?php echo $row_Recordset1['id']; ?></span></div></td>
        <td><span class="style9"><?php echo $row_Recordset1['fname']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['lname']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['gender']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['age']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['status']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['phone']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['dob']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['address']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['procedure']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['visit']; ?></span></td>
        <td><span class="style9"><?php echo $row_Recordset1['date']; ?></span></td>
        <td><a href="Delete.php?id=<?php echo $row_Recordset1['id']; ?>"><img src="cross-23-16.png" width="16" height="16" border="0" /></a></td>
        <td><a href="update.php?id=<?php echo $row_Recordset1['id']; ?>"><img src="to-update-2-16.png" width="16" height="16" border="0" /></a></td>
      </tr>
      <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
      </table>
  <?php } // Show if recordset not empty ?></body>
</html>
<?php
mysql_free_result($Recordset1);
?>
