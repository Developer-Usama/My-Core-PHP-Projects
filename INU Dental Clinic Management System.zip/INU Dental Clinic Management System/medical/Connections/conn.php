<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

$hostname_conn = "localhost";
$database_conn = "medical";
$username_conn = "root";
$password_conn = "";

// Create a MySQLi connection
$conn = new mysqli($hostname_conn, $username_conn, $password_conn, $database_conn);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set (optional, adjust as needed)
$conn->set_charset("utf8");

// Now, $conn is your MySQLi connection object, and you can use it for database queries.
