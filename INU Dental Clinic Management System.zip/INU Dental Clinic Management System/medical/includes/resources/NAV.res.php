<?php
$res = array(
'Page' => 'Page',
'to' => 'to',
'of' => 'of',
'First' => 'First',
'Previous' => 'Previous',
'Next' => 'Next',
'Last' => 'Last',
'apply' => 'apply',
'other' => 'other',
'0_9' => '0-9',
'Records' => 'Records',
'Records per page' => 'Records per page',
'all' => 'all',
);
?>