<?php
$res = array(
'IMAGE_WATERMARK_ERR' => '> Error applying watermark',
'IMAGE_WATERMARK_ERR_D' => '> Error applying watermark',
'WATERMARK_NO_LIB' => '> Error applying watermark. Image processing library not available or does not support operation. %s',
'WATERMARK_NO_LIB_D' => '> Error applying watermark. Image processing library is not available or does not support operation. %s',
'IMG_WATERMARK' => 'Image processing error. Error applying watermark on image.',
'IMG_WATERMARK_D' => '\'Image processing error. Error applying watermark on image: %s',
);
?>