<?php
$res = array(
'SQL_ERROR' => '<strong>Error creating Dynamic Include:</strong><br/>%s<br/><strong>SQL:</strong><br/>%s<br/>',
'MISSING_FIELD' => '<strong>Error creating Dynamic Include:</strong><br/>The field \'%s\' is not in the recordset.<br/>',
'PHP_CHDIR_FAILED' => '<strong>Error including file:</strong><br/>Could not change directory to \'%s\'. Set execute permissions on this folder.<br/>',
);
?>