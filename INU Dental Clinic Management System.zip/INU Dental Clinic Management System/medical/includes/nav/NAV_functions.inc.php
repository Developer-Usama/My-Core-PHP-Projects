<?php
/*
	Copyright (c) InterAKT Online 2000-2006. All rights reserved.
*/

function NAV_getResource($resourceName) {
	return KT_getResource($resourceName, 'NAV');
}

?>
