



function loadTemplatesBy (category, order)
{



	$.post(ajax_object.ajaxurl, {
			action: 'ajax_action',
			category: category,
			order_by: order
		}, function(data) {
			//alert(data); // alerts 'ajax submitted'
			$("#products").html(data);

		});

}