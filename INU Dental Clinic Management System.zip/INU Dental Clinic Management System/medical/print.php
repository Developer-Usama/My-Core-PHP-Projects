<?php
// Include the database connection file
require_once('Connections/conn.php');

// Start a session or resume the existing session
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['MM_Username'])) {
    // Redirect the user to the login page
    header("Location: index.php"); // Replace 'login.php' with your actual login page
    exit(); // Stop executing the current script
}
?>

<?php
$maxRows_Recordset1 = 10;
$pageNum_Recordset1 = 0;
if (isset($_GET['pageNum_Recordset1'])) {
    $pageNum_Recordset1 = $_GET['pageNum_Recordset1'];
}
$startRow_Recordset1 = $pageNum_Recordset1 * $maxRows_Recordset1;


$colname_Recordset1 = "-1";
if (isset($_GET['id'])) {
    $colname_Recordset1 = mysqli_real_escape_string($conn, $_GET['id']); // Sanitize the input
}
// Prepare the query with a placeholder
$query_Recordset1 = "SELECT * FROM registration WHERE id = ?";
$stmt = $conn->prepare($query_Recordset1);

if ($stmt === false) {
    die('Prepare Error: ' . $conn->error);
}

// Bind the parameter
$stmt->bind_param("s", $colname_Recordset1);

// Execute the statement
$stmt->execute();

// Get the result
$result = $stmt->get_result();

if ($result === false) {
    die('Execute Error: ' . $stmt->error);
}

// Fetch the row
$row_Recordset1 = $result->fetch_assoc();



// $totalPages_Recordset1 = ceil($totalRows_Recordset1 / $maxRows_Recordset1) - 1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>IQRA DENTAL CLINIC </title>
    <style type="text/css">
        <!--
        .style1 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 18px;
        }

        .style2 {
            font-size: 14px;
            font-weight: bold;
            color: #990000;
        }

        .style5 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
            font-weight: bold;
        }

        .style8 {
            font-family: Arial, Helvetica, sans-serif
        }

        .style10 {
            font-family: Arial, Helvetica, sans-serif;
            font-weight: bold;
        }

        .style12 {
            font-family: Arial, Helvetica, sans-serif;
            color: #FFFFFF;
        }

        .style13 {
            color: #000000
        }

        .style14 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 12px;
            font-weight: bold;
        }

        .style21 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 9px;
            color: #FFFFFF;
        }

        .style22 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 10px;
            color: #000000;
        }
        -->
    </style>
</head>

<body>
    <table width="760" height="1100" border="0" align="center" background="Untitled-111 copy.png">
        <tr valign="top">
            <td>
                <table width="760" border="0" cellpadding="5" cellspacing="5">
                    <tr>
                        <td width="584" valign="top"><img src="IQRA-logo-black.png" width="166" height="39" /></td>
                        <td width="172">
                            <div align="center" class="style1">
                                <div align="right">
                                    <p class="style2 style13">Dr. SHANDANA WAHAB<br />
                                        BDS, RDS<br />
                                        MCPS, PERIO(PGT)<br />
                                        DENTAL SURGEON</p>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr align="center" valign="middle">
                        <td colspan="2"><img src="cc.png" width="760" height="60" /></td>
                    </tr>
                </table>
                <table width="760" border="0" align="center">
                    <tr>
                        <td><img src="line.jpg" width="760" height="2" /></td>
                    </tr>
                    <tr>
                        <td><span class="style21">0</span></td>
                    </tr>
                    <tr>
                        <td>
                            <div align="right"><span class="style5">Date: <?php echo $row_Recordset1['date']; ?></span></div>
                        </td>
                    </tr>
                    <tr>
                        <td><span class="style10">Patient Name: </span><span class="style8"><?php echo $row_Recordset1['fname']; ?> <?php echo $row_Recordset1['lname']; ?><strong>&nbsp;&nbsp;</strong></span></td>
                    </tr>
                    <tr>
                        <td><span class="style8"><strong>Age:</strong><?php echo $row_Recordset1['age']; ?></span>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span class="style10">Sex:</span> <span class="style8"><?php echo $row_Recordset1['gender']; ?></span></td>
                    </tr>
                    <tr>
                        <td><span class="style10">Contact:</span> <span class="style8"><?php echo $row_Recordset1['phone']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="style10">Patient Status:</span> <?php echo $row_Recordset1['status']; ?></span></td>
                    </tr>
                </table>

                <hr>
                <table width="760" border="0" align="center">
                    <tr>
                        <td width="204"><span class="style21">0</span></td>
                        <td width="546" rowspan="9">
                            <p class="style8"><br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                            </p>
                            <p class="style8"><br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                                <br />
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p class="style5">SYSTEMATIC RECORD</p>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <table width="100%" border="0">
                                <tr>
                                    <td width="80%"><span class="style14">HBs</span></td>
                                    <td width="20%"><span class="style14">
                                            <input type="checkbox" name="checkbox222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Hcv</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">RBS</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2223" value="checkbox" />
                                        </span></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <p class="style5"><span class="style21">0</span></p>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top"><span class="style5">CLINICAL EXAMINATION</span></td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <table width="100%" border="0">
                                <tr>
                                    <td width="81%"><span class="style14">Caries</span></td>
                                    <td width="19%"><span class="style14">
                                            <input type="checkbox" name="checkbox2224" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Pulpitic</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox22222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Impaction</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox22232" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td height="23"><span class="style14">BDR&rsquo;s</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222322" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Gingivitis Periodontitis</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222323" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Missing Teeth</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222324" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Others</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222325" value="checkbox" />
                                        </span></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td valign="top"><span class="style21">0</span></td>
                    </tr>
                    <tr>
                        <td valign="top"><span class="style5">TREATMENT</span></td>
                    </tr>
                    <tr>
                        <td valign="top">
                            <table width="100%" border="0">
                                <tr>
                                    <td width="81%"><span class="style14">Fillings (Composite, GIC)</span></td>
                                    <td width="19%"><span class="style14">
                                            <input type="checkbox" name="checkbox22242" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">RCT</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Pulpotomy</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222326" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td height="23"><span class="style14">Surgery</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2223222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Extraction</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2223232" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Scaling &amp; Polishing</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2223242" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Crown</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox2223252" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Bridge</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox22232522" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Implant</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222325222" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">PD, FD</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222325223" value="checkbox" />
                                        </span></td>
                                </tr>
                                <tr>
                                    <td><span class="style14">Others</span></td>
                                    <td><span class="style14">
                                            <input type="checkbox" name="checkbox222325224" value="checkbox" />
                                        </span></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <table width="760" border="0" align="center">
                    <tr>
                        <td align="right">
                            <span class="style14">Total: <?php echo $row_Recordset1['total']; ?></span><br />
                            <span class="style14">Discount: <?php echo $row_Recordset1['discount']; ?></span><br />
                            <span class="style14"><strong>Grand Total:</strong> <?php echo $row_Recordset1['finalAmount']; ?></span><br />
                        </td>
                    </tr>
                </table>

            </td>
        </tr>
        <tr>
            <td>
                <div align="center"><a href="#" class="style22" onclick="window.print();return false;">Computer Generated</a></div>
            </td>
        </tr>
        <tr>
            <td bgcolor="#000033">
                <div align="center"><span class="style12">091-111-111-468&nbsp;&nbsp; | &nbsp;&nbsp;Hayatabad Phase 2&nbsp; &nbsp;|&nbsp; info@inu.edu.pk </span></div>
            </td>
        </tr>
    </table>
</body>

</html>
<?php
// Check if $result_Recordset1 is set and not null before freeing the result set
if (isset($result_Recordset1) && $result_Recordset1 !== null) {
    $result_Recordset1->free_result();
}

// Close the MySQLi connection
$conn->close();
?>