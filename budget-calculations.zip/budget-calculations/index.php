<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "item_calculations";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_item'])) {
    $name = $_POST['name'];
    $date = $_POST['date'];
    $price = $_POST['price'];

    $sql = "INSERT INTO items (name, date, price) VALUES ('$name', '$date', '$price')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>New item added successfully!</div>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle item deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_item'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM items WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='success'>Item deleted successfully!</div>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch items and calculate the total sum
$sql = "SELECT * FROM items order by date asc";
$result = $conn->query($sql);

$totalSum = 0;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Calculation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        form input[type="text"],
        form input[type="date"],
        form input[type="number"] {
            width: 48%;
            margin-bottom: 10px;
            padding: 10px;
            font-size: 16px;
        }

        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            font-size: 18px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        form input[type="submit"]:hover {
            background-color: #218838;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .delete-btn {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .total-box {
            margin-top: 20px;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            font-size: 18px;
            border-radius: 5px;
        }

        .success {
            color: green;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <div class="container">
        <h1>Item Calculation</h1>
        <form action="" method="POST">
            <input type="text" name="name" placeholder="Item Name" required>
            <input type="date" name="date" required>
            <input type="number" name="price" placeholder="Item Price" step="0.01" required>
            <input type="submit" name="add_item" value="Add Item">
        </form>

        <table>
            <tr>
                <th>Name</th>
                <th>Date</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['name']}</td>
                        <td>{$row['date']}</td>
                        <td>{$row['price']}</td>
                        <td>
                            <form action='' method='POST' style='display:inline;'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <input type='submit' name='delete_item' value='Delete' class='delete-btn'>
                            </form>
                        </td>
                    </tr>";
                    $totalSum += $row['price'];
                }
            } else {
                echo "<tr><td colspan='4'>No items found.</td></tr>";
            }
            ?>
        </table>

        <div class="total-box">
            Total Sum: <?php echo number_format($totalSum, 2); ?> PKR
        </div>
    </div>

</body>

</html>

<?php
$conn->close();
?>